/*
 * Copyright 2020 the original author or authors.
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * https://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.openrewrite;

import com.fasterxml.jackson.annotation.JsonTypeInfo;
import org.jspecify.annotations.Nullable;
import org.openrewrite.binary.Binary;
import org.openrewrite.internal.StringUtils;
import org.openrewrite.marker.Markers;
import org.openrewrite.quark.Quark;

import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

@JsonTypeInfo(use = JsonTypeInfo.Id.CLASS, property = "@c", include = JsonTypeInfo.As.PROPERTY)
public interface Tree {

    static UUID randomId() {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        long msb = (r.nextLong() & 0xffffffffffff0fffL) | 0x0000000000004000L; // version 4
        long lsb = (r.nextLong() & 0x3fffffffffffffffL) | 0x8000000000000000L; // variant IETF
        return new UUID(msb, lsb);
    }

    /**
     * An id that can be used to identify a particular AST element, even after transformations have taken place on it
     *
     * @return A unique identifier
     */
    UUID getId();

    Markers getMarkers();

    <T extends Tree> T withMarkers(Markers markers);

    <T extends Tree> T withId(UUID id);

    /**
     * Supports polymorphic visiting via {@link TreeVisitor#visit(Tree, Object)}. This is useful in cases where an AST
     * type contains a field that is of a type with a hierarchy. The visitor doesn't have to figure out which visit
     * method to call by using instanceof.
     *
     * @param v   visitor
     * @param p   visit context
     * @param <R> visitor return type
     * @param <P> visit context type
     * @return visitor result
     */
    default <R extends Tree, P> @Nullable R accept(TreeVisitor<R, P> v, P p) {
        return v.defaultValue(this, p);
    }

    /**
     * Checks the supplied argument to see if the supplied visitor and its context would be valid arguments
     * to accept().
     * Typically, this involves checking that the visitor is of a type that operates on this kind of tree.
     * e.g.: A Java Tree implementation would return true for JavaVisitors and false for MavenVisitors
     *
     * @param <P> the visitor's context argument
     * @return 'true' if the arguments to this function would be valid arguments to accept()
     */
    <P> boolean isAcceptable(TreeVisitor<?, P> v, P p);

    default <P> TreeVisitor<?, PrintOutputCapture<P>> printer(Cursor cursor) {
        return cursor.firstEnclosingOrThrow(SourceFile.class).printer(cursor);
    }

    default String print(Cursor cursor) {
        return print(cursor, new PrintOutputCapture<>(0));
    }

    default <P> String print(Cursor cursor, PrintOutputCapture<P> out) {
        this.<P>printer(cursor).visit(this, out, cursor);

        // Restore BOM if the source file originally had one
        // should be in sync with the BOM restore logic in SourceFile.printEqualsInput()
        if (this instanceof SourceFile &&
            !(this instanceof Quark) &&
            !(this instanceof Binary)) {
            SourceFile sourceFile = (SourceFile) this;
            try {
                if (sourceFile.isCharsetBomMarked() &&
                        out.out.length() > 0 &&
                        out.out.charAt(0) != '\uFEFF') {
                    out.out.insert(0, '\uFEFF');
                }
            } catch (UnsupportedOperationException e) {
                // Defensive fallback for any other SourceFile implementations that don't support charset operations
            }
        }

        return out.getOut();
    }

    default String print(TreeVisitor<?, PrintOutputCapture<Integer>> printer) {
        PrintOutputCapture<Integer> outputCapture = new PrintOutputCapture<>(0);
        printer.visit(this, outputCapture);
        return outputCapture.getOut();
    }

    default <P> String printTrimmed(P p, Cursor cursor) {
        return StringUtils.trimIndent(print(cursor, new PrintOutputCapture<>(p)));
    }

    default String printTrimmed(Cursor cursor) {
        return StringUtils.trimIndent(print(cursor));
    }

    default String printTrimmed(TreeVisitor<?, PrintOutputCapture<Integer>> printer) {
        return StringUtils.trimIndent(print(printer));
    }

    default boolean isScope(@Nullable Tree tree) {
        if (tree == this) {
            return true;
        }
        //noinspection ConstantConditions
        return tree != null && tree.getId() != null && tree.getId().equals(getId());
    }

    default <T2 extends Tree> T2 cast() {
        //noinspection unchecked
        return (T2) this;
    }
}
