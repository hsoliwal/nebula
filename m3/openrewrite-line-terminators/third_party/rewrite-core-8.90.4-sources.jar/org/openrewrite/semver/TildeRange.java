/*
 * Copyright 2021 the original author or authors.
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * https://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.openrewrite.semver;

import org.jspecify.annotations.Nullable;
import org.openrewrite.Validated;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static java.lang.Long.parseLong;
import static java.util.Objects.requireNonNull;
import static org.openrewrite.semver.Semver.isVersion;

/**
 * Allows patch-level changes if a minor version is specified on the comparator. Allows minor-level changes if not.
 * <a href="https://github.com/npm/node-semver#tilde-ranges-123-12-1">Tilde ranges</a>.
 */
public class TildeRange extends LatestRelease {
    private static final Pattern TILDE_RANGE_PATTERN = Pattern.compile("~(\\d+)(?:\\.(\\d+))?(?:\\.(\\d+))?(?:\\.(\\d+))?");

    // The npm tilde grammar; unlike TILDE_RANGE_PATTERN, no 4th component, wildcards allowed.
    private static final Pattern NODE_TILDE_PATTERN = Pattern.compile("^(?:~>?)" + XRange.XRANGE_PLAIN + "$");

    private final String upperExclusive;
    private final String lower;
    private final boolean requireRelease;

    // Non-null in npm mode; evaluation delegates to it.
    private final @Nullable UnionRange node;

    private TildeRange(String lower, String upperExclusive, @Nullable String metadataPattern, boolean requireRelease) {
        super(metadataPattern);
        this.lower = lower;
        this.upperExclusive = upperExclusive;
        this.requireRelease = requireRelease;
        this.node = null;
    }

    private TildeRange(UnionRange node, @Nullable String metadataPattern) {
        super(metadataPattern);
        this.lower = "";
        this.upperExclusive = "";
        this.requireRelease = false;
        this.node = node;
    }

    @Override
    public boolean isValid(@Nullable String currentVersion, String version) {
        if (node != null) {
            return node.isValidVersion(version, getMetadataPattern());
        }
        return VersionComparator.checkVersion(version, getMetadataPattern(), requireRelease) &&
                super.compare(currentVersion, version, upperExclusive) < 0 &&
                super.compare(currentVersion, version, lower) >= 0;
    }

    public static Validated<TildeRange> build(String pattern, @Nullable String metadataPattern) {
        return build(pattern, metadataPattern, false);
    }
    public static Validated<TildeRange> build(String pattern, @Nullable String metadataPattern, boolean requireRelease) {
        Matcher matcher = TILDE_RANGE_PATTERN.matcher(pattern);
        if (!matcher.matches()) {
            return Validated.invalid("tildeRange", pattern, "not a tilde range");
        }

        String major = matcher.group(1);
        String minor = matcher.group(2);
        String patch = matcher.group(3);
        String micro = matcher.group(4);

        String lower;
        String upper;

        if (minor == null) {
            lower = major;
            upper = Long.toString(parseLong(major) + 1);
        } else if (patch == null) {
            lower = major + "." + minor;
            upper = major + "." + (parseLong(minor) + 1);
        } else if (micro == null) {
            lower = major + "." + minor + "." + patch;
            upper = major + "." + (parseLong(minor) + 1);
        } else {
            lower = major + "." + minor + "." + patch + "." + micro;
            upper = major + "." + minor + "." + (parseLong(patch) + 1);
        }

        return Validated.valid("tildeRange", new TildeRange(lower, upper, metadataPattern, requireRelease));
    }

    static Validated<VersionComparator> buildNode(String pattern, @Nullable String metadataPattern) {
        if (!NODE_TILDE_PATTERN.matcher(pattern.trim()).matches()) {
            return Validated.invalid("tildeRange", pattern, "not a node tilde range");
        }
        UnionRange node = UnionRange.parse(pattern, false);
        if (node == null) {
            return Validated.invalid("tildeRange", pattern, "not a valid node range");
        }
        return Validated.valid("tildeRange", new TildeRange(node, metadataPattern));
    }

    // Port of node-semver range.js replaceTilde; non-tilde tokens pass through.
    static String replaceTilde(String token, boolean incPre) {
        Matcher m = NODE_TILDE_PATTERN.matcher(token);
        if (!m.matches()) {
            return token;
        }
        String mj = m.group(1), mn = m.group(2), p = m.group(3), pr = m.group(4);
        String z = incPre ? "-0" : "";
        if (XRange.isX(mj)) {
            return "";
        }
        if (XRange.isX(mn)) {
            return ">=" + mj + ".0.0" + z + " <" + NodeComparand.incr(mj) + ".0.0-0";
        }
        if (XRange.isX(p)) {
            return ">=" + mj + "." + mn + ".0" + z + " <" + mj + "." + NodeComparand.incr(mn) + ".0-0";
        }
        if (pr != null) {
            return ">=" + mj + "." + mn + "." + p + "-" + pr + " <" + mj + "." + NodeComparand.incr(mn) + ".0-0";
        }
        return ">=" + mj + "." + mn + "." + p + z + " <" + mj + "." + NodeComparand.incr(mn) + ".0-0";
    }

    @Override
    public String toString() {
        return node != null ? node.toString() : super.toString();
    }

    @Override
    public int compare(@Nullable String currentVersion, String v1, String v2) {
        if (node != null) {
            return ParsedVersion.compareLenient(v1, v2);
        }
        Validated<TildeRange> maybeTildeRangeV1 = build(v1, null);
        Validated<TildeRange> maybeTildeRangeV2 = build(v2, null);
        if (maybeTildeRangeV1.isValid() && maybeTildeRangeV2.isValid()) {
            TildeRange tildeRangeV1 = requireNonNull(maybeTildeRangeV1.getValue());
            TildeRange tildeRangeV2 = requireNonNull(maybeTildeRangeV2.getValue());
            int compare = super.compare(currentVersion, tildeRangeV1.upperExclusive, tildeRangeV2.upperExclusive);
            if (compare != 0) {
                return compare;
            }

            return super.compare(currentVersion, tildeRangeV1.lower, tildeRangeV2.lower);
        } else if (maybeTildeRangeV1.isValid()) {
            if (!isVersion(v2)) {
                return 1;
            }

            TildeRange tildeRangeV1 = requireNonNull(maybeTildeRangeV1.getValue());
            int compare = super.compare(currentVersion, tildeRangeV1.upperExclusive, v2);
            if (compare < 0) {
                return compare;
            } else if (compare == 0) {
                return -1;
            }

            compare = super.compare(currentVersion, tildeRangeV1.lower, v2);
            return Math.max(compare, 0);
        } else if (maybeTildeRangeV2.isValid()) {
            if (!isVersion(v1)) {
                return -1;
            }

            TildeRange tildeRangeV2 = requireNonNull(maybeTildeRangeV2.getValue());
            int compare = super.compare(currentVersion, v1, tildeRangeV2.upperExclusive);
            if (compare > 0) {
                return compare;
            } else if (compare == 0) {
                return 1;
            }

            compare = super.compare(currentVersion, v1, tildeRangeV2.lower);
            return Math.min(compare, 0);
        }

        return super.compare(currentVersion, v1, v2);
    }
}
