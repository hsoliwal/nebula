/*
 * Copyright 2023 the original author or authors.
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * https://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.openrewrite.remote;

import org.jspecify.annotations.Nullable;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.UUID;
import java.util.function.Consumer;

public class LocalRemoteArtifactCache implements RemoteArtifactCache {
    private static final char[] HEX_ARRAY = "0123456789abcdef".toCharArray();
    private static final ThreadLocal<MessageDigest> DIGEST = ThreadLocal.withInitial(() -> {
        try {
            return MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    });

    private final Path cacheDir;

    public LocalRemoteArtifactCache(Path cacheDir) {
        if (!cacheDir.toFile().exists() && !cacheDir.toFile().mkdirs()) {
            throw new IllegalStateException("Unable to find or create remote archive cache at " + cacheDir);
        }
        this.cacheDir = cacheDir;
    }

    @Override
    public @Nullable Path get(URI uri) {
        Path resolved = cacheDir.resolve(hashUri(uri));
        return Files.exists(resolved) ? resolved : null;
    }

    @Override
    public @Nullable Path put(URI uri, InputStream artifactInputStream, Consumer<Throwable> onError) {
        synchronized (this) {
            Path artifact = cacheDir.resolve(UUID.randomUUID() + ".tmp");
            try (InputStream is = artifactInputStream) {
                Files.copy(is, artifact, StandardCopyOption.REPLACE_EXISTING);
                Path cachedArtifact = cacheDir.resolve(hashUri(uri));
                if (!Files.exists(cachedArtifact)) {
                    Files.move(artifact, cachedArtifact, StandardCopyOption.ATOMIC_MOVE,
                            StandardCopyOption.REPLACE_EXISTING);
                }
                return cachedArtifact;
            } catch (Exception e) {
                onError.accept(e);
                return null;
            } finally {
                if (Files.exists(artifact)) {
                    try {
                        Files.delete(artifact);
                    } catch (IOException ignored) {
                        // Suppress
                    }
                }
            }
        }
    }

    public static String hashUri(URI uri) {
        MessageDigest digest = DIGEST.get();
        digest.reset();
        byte[] hashBytes = digest.digest(uri.toString().getBytes(StandardCharsets.UTF_8));

        char[] hexChars = new char[hashBytes.length * 2];
        for (int i = 0; i < hashBytes.length; i++) {
            int v = hashBytes[i] & 0xFF;
            hexChars[i * 2] = HEX_ARRAY[v >>> 4];
            hexChars[i * 2 + 1] = HEX_ARRAY[v & 0x0F];
        }
        return new String(hexChars);
    }
}
