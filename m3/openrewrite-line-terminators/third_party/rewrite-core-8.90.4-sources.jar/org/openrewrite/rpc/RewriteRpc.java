/*
 * Copyright 2025 the original author or authors.
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * https://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.openrewrite.rpc;

import io.moderne.jsonrpc.JsonRpc;
import io.moderne.jsonrpc.JsonRpcMethod;
import io.moderne.jsonrpc.JsonRpcRequest;
import io.moderne.jsonrpc.JsonRpcSuccess;
import io.moderne.jsonrpc.RawJson;
import io.moderne.jsonrpc.internal.SnowflakeId;
import org.jetbrains.annotations.VisibleForTesting;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;
import org.openrewrite.*;
import org.openrewrite.internal.RecipeLoader;
import org.openrewrite.marketplace.RecipeBundle;
import org.openrewrite.marketplace.RecipeBundleResolver;
import org.openrewrite.marketplace.RecipeListing;
import org.openrewrite.marketplace.RecipeMarketplace;
import org.openrewrite.rpc.internal.PreparedRecipeCache;
import org.openrewrite.rpc.request.*;
import org.openrewrite.tree.ParseError;
import org.openrewrite.tree.ParsingEventListener;
import org.openrewrite.tree.ParsingExecutionContextView;

import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import static java.util.Collections.emptyList;
import static java.util.Collections.emptyMap;
import static java.util.Objects.requireNonNull;
import static java.util.stream.Collectors.toList;
import static org.openrewrite.rpc.RpcObjectData.State.END_OF_OBJECT;

/**
 * Base class for RPC clients with thread-local context support.
 */
@SuppressWarnings("UnusedReturnValue")
public class RewriteRpc {
    private static final ThreadLocal<@Nullable RewriteRpc> CURRENT = new ThreadLocal<>();

    private final JsonRpc jsonRpc;
    private final AtomicInteger batchSize = new AtomicInteger(1000);
    private Duration timeout = Duration.ofSeconds(30);
    private Supplier<? extends @Nullable RuntimeException> livenessCheck = () -> null;
    private final AtomicReference<@Nullable PrintStream> log = new AtomicReference<>();
    private final AtomicReference<TraceGetObject> traceGetObject = new AtomicReference<>(
            new TraceGetObject(false, false));

    final PreparedRecipeCache preparedRecipes = new PreparedRecipeCache();

    /**
     * Keeps track of the local and remote state of objects that are used in
     * visits and other operations for which incremental state sharing is useful
     * between two processes. Note these do not need to be ConcurrentHashMap as
     * each RewriteRpc instance is held in its own ThreadLocal in RewriteRpcProcessManager
     */
    @VisibleForTesting
    final Map<String, Object> remoteObjects = new HashMap<>();

    @VisibleForTesting
    final Map<String, Object> localObjects = new HashMap<>();

    /* A reverse map of the objects back to their IDs */
    final Map<Object, String> localObjectIds = new IdentityHashMap<>();

    @VisibleForTesting
    final Map<Integer, Object> remoteRefs = new HashMap<>();

    @VisibleForTesting
    final IdentityHashMap<Object, Integer> localRefs = new IdentityHashMap<>();

    private @Nullable List<String> remoteLanguages;

    private volatile @Nullable DataTableStore configuredDataTableStore;

    private @Nullable SetDataTableStore pendingDataTableStore;
    private boolean dataTableStoreSent;

    /**
     * Creates a new RPC interface that can be used to communicate with a remote.
     *
     * @param marketplace The marketplace of recipes that this peer makes available.
     *                    Even if this peer is the host process, configuring this
     *                    marketplace allows the remote peer to discover what recipes
     *                    the host process has available for its use in composite recipes.
     */
    public RewriteRpc(JsonRpc jsonRpc, RecipeMarketplace marketplace) {
        this(jsonRpc, marketplace, emptyList());
    }

    /**
     * Mutable resolver list so it can be updated after construction
     * (e.g. when the RPC process is started eagerly before all resolvers are built).
     */
    private final List<RecipeBundleResolver> resolvers = new ArrayList<>();

    /**
     * Parsers available for handling Parse requests from remote peers.
     */
    private final List<Parser> parsers = new ArrayList<>();

    private final RecipeMarketplace marketplace;

    /**
     * Replace the resolver list. Useful when the RPC process is started before all
     * resolvers are built (e.g. the NuGet resolver starts the C# RPC during
     * buildResolvers, but Maven resolvers are added to the list afterward).
     */
    public void setResolvers(List<RecipeBundleResolver> resolvers) {
        this.resolvers.clear();
        this.resolvers.addAll(resolvers);
    }

    /**
     * Set the parsers available for handling Parse requests from remote peers.
     */
    public void setParsers(List<Parser> parsers) {
        this.parsers.clear();
        this.parsers.addAll(parsers);
    }

    /**
     * Creates a new RPC interface that can be used to communicate with a remote.
     *
     * @param marketplace The marketplace of recipes that this peer makes available.
     *                    Even if this peer is the host process, configuring this
     *                    marketplace allows the remote peer to discover what recipes
     *                    the host process has available for its use in composite recipes.
     * @param resolvers   The initial set of recipe bundle resolvers.
     */
    public RewriteRpc(JsonRpc jsonRpc, RecipeMarketplace marketplace, List<RecipeBundleResolver> resolvers) {
        this.jsonRpc = jsonRpc;
        this.marketplace = marketplace;
        this.resolvers.addAll(resolvers);

        // Install the configured store on each reconstructed ExecutionContext, keeping that out of the handlers.
        BiFunction<String, @Nullable String, ?> getRecipeObject = (id, sourceFileType) -> {
            Object o = getObject(id, sourceFileType);
            DataTableStore store = configuredDataTableStore;
            if (store != null && o instanceof ExecutionContext) {
                DataTableExecutionContextView.view((ExecutionContext) o).setDataTableStore(store);
            }
            return o;
        };
        jsonRpc.rpc("Visit", new Visit.Handler(this, localObjects, preparedRecipes,
                getRecipeObject, this::getCursor));
        jsonRpc.rpc("BatchVisit", new BatchVisit.Handler(this, localObjects, preparedRecipes,
                getRecipeObject, this::getCursor));
        jsonRpc.rpc("Generate", new Generate.Handler(localObjects, preparedRecipes,
                getRecipeObject));
        jsonRpc.rpc("GetObject", new GetObject.Handler(batchSize, remoteObjects, localObjects,
                localRefs, log, () -> traceGetObject.get().isSend()));
        jsonRpc.rpc("GetMarketplace", new JsonRpcMethod<Void>() {
            @Override
            protected Object handle(Void noParams) {
                return GetMarketplaceResponse.fromMarketplace(marketplace, RewriteRpc.this.resolvers);
            }
        });
        jsonRpc.rpc("TraceGetObject", new JsonRpcMethod<TraceGetObject>() {
            @Override
            protected Boolean handle(TraceGetObject request) {
                traceGetObject.set(request);
                return true;
            }
        });
        jsonRpc.rpc("GetLanguages", new JsonRpcMethod<Void>() {
            @Override
            protected Object handle(Void noParams) {
                // Advertise every SourceFile type Java has a receiver for so that
                // remote peers know they can hand any of these off to Java for
                // visiting. Each entry is gated by ifOnClasspath so the actual
                // set narrows to whichever rewrite-* modules are loaded in this
                // process.
                return Stream.of(
                        ifOnClasspath("org.openrewrite.text.PlainText"),
                        ifOnClasspath("org.openrewrite.json.tree.Json$Document"),
                        ifOnClasspath("org.openrewrite.yaml.tree.Yaml$Documents"),
                        ifOnClasspath("org.openrewrite.xml.tree.Xml$Document"),
                        ifOnClasspath("org.openrewrite.hcl.tree.Hcl$ConfigFile"),
                        ifOnClasspath("org.openrewrite.properties.tree.Properties$File"),
                        ifOnClasspath("org.openrewrite.toml.tree.Toml$Document"),
                        ifOnClasspath("org.openrewrite.protobuf.tree.Proto$Document"),
                        ifOnClasspath("org.openrewrite.docker.tree.Docker$File"),
                        ifOnClasspath("org.openrewrite.java.tree.J$CompilationUnit"),
                        ifOnClasspath("org.openrewrite.javascript.tree.JS$CompilationUnit"),
                        ifOnClasspath("org.openrewrite.kotlin.tree.K$CompilationUnit"),
                        ifOnClasspath("org.openrewrite.groovy.tree.G$CompilationUnit"),
                        ifOnClasspath("org.openrewrite.csharp.tree.Cs$CompilationUnit"),
                        ifOnClasspath("org.openrewrite.python.tree.Py$CompilationUnit"),
                        ifOnClasspath("org.openrewrite.golang.tree.Go$CompilationUnit"),
                        ifOnClasspath("org.openrewrite.scala.tree.S$CompilationUnit")
                ).filter(Objects::nonNull).toArray(String[]::new);
            }

            private @Nullable String ifOnClasspath(String className) {
                try {
                    Class.forName(className);
                    return className;
                } catch (ClassNotFoundException e) {
                    return null;
                }
            }
        });
        jsonRpc.rpc("PrepareRecipe", new PrepareRecipe.Handler(preparedRecipes, (id, opts) -> {
            RecipeListing listing = marketplace.findRecipe(id);
            if (listing != null) {
                return listing.prepare(RewriteRpc.this.resolvers, opts);
            }
            // Fall back to loading by class name if not found in marketplace
            return new RecipeLoader(null).load(id, opts);
        }));
        jsonRpc.rpc("Parse", new Parse.Handler(localObjects, () -> parsers));
        jsonRpc.rpc("Print", new Print.Handler(this::getObject));
        jsonRpc.rpc("SetDataTableStore", new SetDataTableStore.Handler(
                store -> configuredDataTableStore = store));
        jsonRpc.rpc("Reset", new JsonRpcMethod<Void>() {
            @Override
            protected Boolean handle(Void noParams) {
                remoteObjects.clear();
                localObjects.clear();
                localObjectIds.clear();
                remoteRefs.clear();
                localRefs.clear();
                preparedRecipes.getInstantiated().clear();
                preparedRecipes.getRecipeCursors().clear();
                return true;
            }
        });
        jsonRpc.rpc("Evict", new JsonRpcMethod<Evict>() {
            @Override
            protected Boolean handle(Evict request) {
                // Inbound side has no per-file checkpoint, so refs are left for Reset.
                remoteObjects.remove(request.getId());
                localObjects.remove(request.getId());
                return true;
            }
        });

        jsonRpc.bind();
    }

    /**
     * The instance the request currently being handled on this thread arrived on, or
     * {@code null} outside request handling. Lets a visitor dispatch follow-up visits back
     * to the requesting peer when this process is the spawned server and has no other
     * handle to it.
     */
    public static @Nullable RewriteRpc current() {
        return CURRENT.get();
    }

    /**
     * Runs {@code work} with this instance discoverable via {@link #current()}.
     */
    public <T> T withCurrent(Callable<T> work) throws Exception {
        RewriteRpc previous = CURRENT.get();
        CURRENT.set(this);
        try {
            return work.call();
        } finally {
            if (previous == null) {
                CURRENT.remove();
            } else {
                CURRENT.set(previous);
            }
        }
    }

    public RewriteRpc livenessCheck(Supplier<? extends @Nullable RuntimeException> livenessCheck) {
        this.livenessCheck = livenessCheck;
        return this;
    }

    public RewriteRpc timeout(Duration timeout) {
        this.timeout = timeout;
        return this;
    }

    public RewriteRpc batchSize(int batchSize) {
        this.batchSize.set(batchSize);
        return this;
    }

    public RewriteRpc log(@Nullable PrintStream logFile) {
        this.log.set(logFile);
        return this;
    }

    /**
     * Configure where recipes in the remote runtime write data table rows. Only the store's
     * configuration crosses the boundary (lazily, before the first visit/generate), never rows.
     * A {@code null} or non-conveyable store leaves the remote on its own default.
     *
     * @see SetDataTableStore
     */
    public RewriteRpc dataTableStore(@Nullable DataTableStore store) {
        this.pendingDataTableStore = SetDataTableStore.from(store);
        this.dataTableStoreSent = false;
        return this;
    }

    private void ensureDataTableStoreSent() {
        if (pendingDataTableStore != null && !dataTableStoreSent) {
            send("SetDataTableStore", pendingDataTableStore, Boolean.class);
            dataTableStoreSent = true;
        }
    }

    @VisibleForTesting
    public @Nullable DataTableStore getConfiguredDataTableStore() {
        return configuredDataTableStore;
    }

    public void shutdown() {
        PrintStream logOut = log.get();
        if (logOut != null) {
            logOut.close();
        }
        jsonRpc.shutdown();
    }

    /**
     * Resets all cached state in both the local and remote RPC processes.
     * This should be called between operations that don't share state (e.g., between tests)
     * to prevent unbounded memory growth from accumulated objects.
     */
    public void reset() {
        // Send reset to remote process
        send("Reset", null, Boolean.class);

        // Clear local caches
        remoteObjects.clear();
        localObjects.clear();
        localObjectIds.clear();
        remoteRefs.clear();
        localRefs.clear();
        remoteLanguages = null;
    }

    /**
     * Ref high-water marks (send-side count, receive-side max key) captured before a file is
     * visited so {@link #evict} rolls back exactly that file's refs. Receive-side uses the max
     * key, not the size, because remote ids may be zero-based.
     */
    public int[] refCheckpoint() {
        int remoteRefsMax = -1;
        for (Integer ref : remoteRefs.keySet()) {
            if (ref > remoteRefsMax) {
                remoteRefsMax = ref;
            }
        }
        return new int[]{localRefs.size(), remoteRefsMax};
    }

    /**
     * Drop a file's tree from both peers and roll their refs back to the pre-file checkpoint.
     * Symmetric by design: dropping the send-side ref forces the next file to re-{@code ADD} the
     * interned object instead of a {@code REF_USE} the rolled-back receiver would reject. Notified
     * fire-and-forget — under source-outer iteration the file's transfer is already complete.
     *
     * @param localRefsCheckpoint  {@code refCheckpoint()[0]} captured before the file was visited
     * @param remoteRefsCheckpoint {@code refCheckpoint()[1]} captured before the file was visited
     */
    public void evict(String id, int localRefsCheckpoint, int remoteRefsCheckpoint) {
        jsonRpc.notify(new JsonRpcRequest(null, "Evict", RawJson.of(new Evict(id))));

        remoteObjects.remove(id);
        localObjects.remove(id);

        localRefs.values().removeIf(ref -> ref > localRefsCheckpoint);
        remoteRefs.keySet().removeIf(ref -> ref > remoteRefsCheckpoint);
    }

    public <P> @Nullable Tree visit(SourceFile sourceFile, String visitorName, P p) {
        return visit(sourceFile, visitorName, p, null);
    }

    public <P> @Nullable Tree visit(Tree tree, String visitorName, P p, @Nullable Cursor cursor) {
        return visit(tree, visitorName, null, p, cursor);
    }

    /**
     * Run a remote visitor that takes constructor arguments (e.g. the peer's own {@code AddImport}),
     * or {@code null} {@code visitorOptions} when it takes none.
     */
    public <P> @Nullable Tree visit(Tree tree, String visitorName, @Nullable Map<String, Object> visitorOptions,
                                    P p, @Nullable Cursor cursor) {
        ensureDataTableStoreSent();
        // Set the local state of this tree, so that when the remote asks for it, we know what to send.
        localObjects.put(tree.getId().toString(), tree);

        String pId = maybeUnwrapExecutionContext(p);
        List<String> cursorIds = getCursorIds(cursor);

        String sourceFileType = DynamicDispatchRpcCodec.canonicalSourceFileType(
                (tree instanceof SourceFile ? tree : requireNonNull(cursor).firstEnclosingOrThrow(SourceFile.class)).getClass());
        Supplier<VisitResponse> doSend = () -> send("Visit", new Visit(visitorName, sourceFileType, visitorOptions,
                tree.getId().toString(), pId, cursorIds), VisitResponse.class);
        VisitResponse response = p instanceof ExecutionContext
                ? RewriteRpcExecutionContextView.view((ExecutionContext) p).withInFlightSlot(doSend)
                : doSend.get();
        return response.isModified() ?
                getObject(tree.getId().toString(), sourceFileType) :
                tree;
    }

    public <P> BatchVisitResponse batchVisit(Tree tree, P p, @Nullable Cursor cursor,
                                             List<BatchVisit.BatchVisitItem> visitors) {
        ensureDataTableStoreSent();
        String treeId = tree.getId().toString();
        localObjects.put(treeId, tree);

        String pId = maybeUnwrapExecutionContext(p);
        List<String> cursorIds = getCursorIds(cursor);

        String sourceFileType = DynamicDispatchRpcCodec.canonicalSourceFileType(
                (tree instanceof SourceFile ? tree : requireNonNull(cursor).firstEnclosingOrThrow(SourceFile.class)).getClass());
        Supplier<BatchVisitResponse> doSend = () -> send("BatchVisit",
                new BatchVisit(sourceFileType, treeId, pId, cursorIds, visitors),
                BatchVisitResponse.class);
        return p instanceof ExecutionContext
                ? RewriteRpcExecutionContextView.view((ExecutionContext) p).withInFlightSlot(doSend)
                : doSend.get();
    }

    public Collection<? extends SourceFile> generate(String remoteRecipeId, ExecutionContext ctx) {
        ensureDataTableStoreSent();
        String ctxId = maybeUnwrapExecutionContext(ctx);
        GenerateResponse response = RewriteRpcExecutionContextView.view(ctx).withInFlightSlot(() ->
                send("Generate", new Generate(remoteRecipeId, ctxId), GenerateResponse.class));
        if (!response.getIds().isEmpty()) {
            List<SourceFile> generated = new ArrayList<>(response.getIds().size());
            for (int i = 0; i < response.getIds().size(); i++) {
                String id = response.getIds().get(i);
                generated.add(getObject(id, response.getSourceFileTypes().get(i)));
            }
            return generated;
        }
        return emptyList();
    }

    /**
     * If the p object is a DelegatingExecutionContext, unwrap it to get the underlying
     * ExecutionContext
     *
     * @param p   A visitor parameter, which may or may not be an ExecutionContext
     * @param <P> The type of p
     * @return The ID of p as represented in the local object cache.
     */
    private <P> String maybeUnwrapExecutionContext(P p) {
        Object p2 = p;
        while (p2 instanceof DelegatingExecutionContext) {
            p2 = ((DelegatingExecutionContext) p2).getDelegate();
        }
        String pId = localObjectIds.computeIfAbsent(p2, p3 -> SnowflakeId.generateId());
        if (p2 instanceof ExecutionContext) {
            ((ExecutionContext) p2).putMessage("org.openrewrite.rpc.id", pId);
        }
        localObjects.put(pId, p2);
        return pId;
    }

    public RecipeMarketplace getMarketplace(RecipeBundle bundle) {
        return send("GetMarketplace", null, GetMarketplaceResponse.class)
                .toMarketplace(bundle);
    }

    public List<String> getLanguages() {
        if (remoteLanguages == null) {
            remoteLanguages = Arrays.asList(send("GetLanguages", null, String[].class));
        }
        return remoteLanguages;
    }

    public Recipe prepareRecipe(String id) {
        return prepareRecipe(id, emptyMap());
    }

    public Recipe prepareRecipe(String id, Map<String, Object> options) {
        // Required-option validation is enforced server-side: PrepareRecipe instantiates the whole
        // tree there and validates each recipe's option values (root and children alike), which a
        // host-side check on the root descriptor alone cannot cover.
        PrepareRecipeResponse r = send("PrepareRecipe", new PrepareRecipe(id, options), PrepareRecipeResponse.class);
        return recipeFromPrepareResponse(r);
    }

    Recipe recipeFromPrepareResponse(PrepareRecipeResponse r) {
        if (r.getDelegatesTo() != null) {
            PrepareRecipeResponse.DelegatesTo d = r.getDelegatesTo();
            RecipeListing listing = marketplace.findRecipe(d.getRecipeName());
            if (listing == null) {
                throw new IllegalStateException(
                        "Remote declared delegatesTo " + d.getRecipeName() +
                        " but no recipe found in marketplace.");
            }
            return listing.prepare(resolvers, d.getOptions());
        }
        return new RpcRecipe(this, r.getId(), r.getDescriptor(), r.getEditVisitor(),
                matchAll(r.getEditPreconditions()), r.getScanVisitor(), matchAll(r.getScanPreconditions()),
                r.getRecipeList());
    }

    private @Nullable TreeVisitor<?, ExecutionContext> matchAll(List<PrepareRecipeResponse.Precondition> preconditions) {
        if (preconditions.isEmpty()) {
            return null;
        }

        List<TreeVisitor<?, ExecutionContext>> visitors = new ArrayList<>(preconditions.size());
        for (PrepareRecipeResponse.Precondition p : preconditions) {
            visitors.add(buildPreconditionVisitor(p));
        }

        return new TreeVisitor<Tree, ExecutionContext>() {
            @Override
            public @Nullable Tree preVisit(Tree tree, ExecutionContext ctx) {
                stopAfterPreVisit();
                Tree t = tree;
                for (TreeVisitor<?, ExecutionContext> v : visitors) {
                    //noinspection unchecked
                    t = ((TreeVisitor<Tree, @NonNull ExecutionContext>) v).visit(tree, ctx);
                    if (t == tree) {
                        // One of the preconditions didn't match, so we fail the whole precondition
                        return tree;
                    }
                }
                return t;
            }
        };
    }

    @SuppressWarnings("unchecked")
    private TreeVisitor<?, ExecutionContext> buildPreconditionVisitor(PrepareRecipeResponse.Precondition p) {
        String op = p.getOp();
        if (op == null) {
            return preparedRecipes.instantiateVisitor(p.getVisitorName(), p.getVisitorOptions());
        }
        List<PrepareRecipeResponse.Precondition> operands = p.getOperands();
        if (operands == null || operands.isEmpty()) {
            throw new IllegalStateException("Composite precondition op=" + op + " requires non-empty operands");
        }
        TreeVisitor<?, ExecutionContext>[] children = new TreeVisitor[operands.size()];
        for (int i = 0; i < operands.size(); i++) {
            children[i] = buildPreconditionVisitor(operands.get(i));
        }
        switch (op) {
            case "or":
                return Preconditions.or(children);
            case "and":
                return Preconditions.and(children);
            case "not":
                if (children.length != 1) {
                    throw new IllegalStateException("Composite precondition op=not requires exactly one operand, got " + children.length);
                }
                return Preconditions.not(children[0]);
            default:
                throw new IllegalStateException("Unknown composite precondition op=" + op);
        }
    }

    public Stream<SourceFile> parse(Iterable<Parser.Input> inputs, @Nullable Path relativeTo,
                                    Parser parser, String sourceFileType, ExecutionContext ctx) {
        return parse(inputs, relativeTo, parser, sourceFileType, ctx, null);
    }

    public Stream<SourceFile> parse(Iterable<Parser.Input> inputs, @Nullable Path relativeTo,
                                    Parser parser, String sourceFileType, ExecutionContext ctx,
                                    @Nullable Map<String, String> options) {
        List<Parser.Input> inputList = new ArrayList<>();
        List<Parse.Input> mappedInputs = new ArrayList<>();
        for (Parser.Input input : inputs) {
            inputList.add(input);
            if (input.isSynthetic() || !Files.isRegularFile(input.getPath())) {
                mappedInputs.add(new Parse.Input(input.getSource(ctx).readFully(), input.getPath()));
            } else {
                mappedInputs.add(new Parse.Input(null, input.getPath()));
            }
        }

        if (inputList.isEmpty()) {
            return Stream.empty();
        }

        ParsingEventListener parsingListener = ParsingExecutionContextView.view(ctx).getParsingListener();
        parsingListener.intermediateMessage(String.format("Starting parsing of %,d files", inputList.size()));

        return StreamSupport.stream(new Spliterator<SourceFile>() {
            private int index = 0;
            private @Nullable List<String> ids;

            @Override
            public boolean tryAdvance(Consumer<? super SourceFile> action) {
                if (ids == null) {
                    // FIXME handle `TimeoutException` gracefully
                    ids = RewriteRpcExecutionContextView.view(ctx).withInFlightSlot(() ->
                            send("Parse", new Parse(mappedInputs, relativeTo != null ? relativeTo.toString() : null, options), ParseResponse.class));
                    assert ids.size() == inputList.size();
                }

                // Process current item in batch
                if (index >= inputList.size()) {
                    return false;
                }

                Parser.Input input = inputList.get(index);
                String id = ids.get(index);
                index++;

                SourceFile sourceFile = null;
                parsingListener.startedParsing(input);
                try {
                    // input.getRelativePath(relativeTo)
                    sourceFile = getObject(id, sourceFileType);
                    // TODO this should be handled on the remote side.
//                    sourceFile = parser.requirePrintEqualsInput(sourceFile, input, relativeTo, ctx);
                } catch (Exception e) {
                    sourceFile = ParseError.build(parser, input, relativeTo, ctx, e);
                } finally {
                    if (sourceFile != null) {
                        action.accept(sourceFile);
                        parsingListener.parsed(input, sourceFile);
                    }
                }
                return true;
            }

            @Override
            public @Nullable Spliterator<SourceFile> trySplit() {
                return null;
            }

            @Override
            public long estimateSize() {
                return inputList.size() - index;
            }

            @Override
            public int characteristics() {
                return ORDERED | SIZED | SUBSIZED;
            }
        }, false);
    }

    public String print(SourceFile tree) {
        return print(tree, new Cursor(null, tree), null);
    }

    public String print(SourceFile tree, Print.@Nullable MarkerPrinter markerPrinter) {
        return print(tree, new Cursor(null, tree), markerPrinter);
    }

    public String print(Tree tree, Cursor parent) {
        return print(tree, parent, null);
    }

    public String print(Tree tree, Cursor parent, Print.@Nullable MarkerPrinter markerPrinter) {
        String treeId = tree.getId().toString();
        localObjects.put(treeId, tree);
        SourceFile sourceFile = tree instanceof SourceFile ? (SourceFile) tree : parent.firstEnclosingOrThrow(SourceFile.class);
        String sourceFileType = DynamicDispatchRpcCodec.canonicalSourceFileType(sourceFile.getClass());

        return send(
                "Print",
                new Print(
                        treeId,
                        sourceFile.getSourcePath(),
                        sourceFileType,
                        markerPrinter
                ),
                String.class
        );
    }

    public RewriteRpc traceGetObject(boolean receive, boolean send) {
        this.traceGetObject.set(new TraceGetObject(receive, send));
        send("TraceGetObject", new TraceGetObject(receive, send), Boolean.class);
        return this;
    }

    @VisibleForTesting
    @Nullable
    List<String> getCursorIds(@Nullable Cursor cursor) {
        List<String> cursorIds = null;
        if (cursor != null) {
            cursorIds = cursor.getPathAsStream().map(c -> {
                String id = c instanceof Tree ?
                        ((Tree) c).getId().toString() :
                        localObjectIds.computeIfAbsent(c, c2 -> SnowflakeId.generateId());
                localObjects.put(id, c);
                return id;
            }).collect(toList());
        }
        return cursorIds;
    }

    @VisibleForTesting
    public <T> T getObject(String id, @Nullable String sourceFileType) {
        // Use the last synced state as the baseline for receiving diffs.
        // This must match what the remote used as its baseline when computing the diff.
        // Using localObjects here would be wrong if Java modified the tree locally
        // (e.g., via a Java-side recipe) since the remote doesn't know about those changes.
        Object before = remoteObjects.get(id);

        RpcReceiveQueue q = new RpcReceiveQueue(
                remoteRefs,
                () -> send("GetObject", new GetObject(id, sourceFileType), GetObjectResponse.class),
                sourceFileType,
                log.get()
        );
        Object remoteObject;
        try {
            remoteObject = q.receive(before, null);
        } catch (Exception e) {
            // Reset our tracking of the remote state so the next interaction
            // forces a full object sync (ADD) instead of a delta (CHANGE).
            remoteObjects.remove(id);
            throw e;
        }
        RpcObjectData endMarker = q.take();
        if (endMarker.getState() != END_OF_OBJECT) {
            throw new IllegalStateException("Expected END_OF_OBJECT but got: " + endMarker);
        }

        //noinspection ConstantValue
        if (remoteObject != null) {
            // We are now in sync with the remote state of the object.
            remoteObjects.put(id, requireNonNull(remoteObject));
            localObjects.put(id, remoteObject);
        }

        //noinspection unchecked
        return (T) remoteObject;
    }

    protected <P> P send(String method, @Nullable RpcRequest body, Class<P> responseType) {
        checkLiveness();
        try {

            // Send the request and get the future
            CompletableFuture<JsonRpcSuccess> future = jsonRpc.send(JsonRpcRequest.newRequest(method, body));

            // future.get(timeout) from a FJP worker triggers ManagedBlocker compensation,
            // which spawns helper threads that can leak per-thread RewriteRpc state.
            long pollIntervalMs = 1;
            long livenessIntervalNanos = TimeUnit.MILLISECONDS.toNanos(500);
            long startNanos = System.nanoTime();
            long deadlineNanos = startNanos + TimeUnit.MILLISECONDS.toNanos(timeout.toMillis());
            long lastLivenessNanos = startNanos;
            while (System.nanoTime() < deadlineNanos) {
                JsonRpcSuccess result = future.getNow(null);
                if (result != null) {
                    return result.getResult(responseType);
                }
                if (future.isCompletedExceptionally()) {
                    return future.get().getResult(responseType);
                }
                Thread.sleep(pollIntervalMs);
                long nowNanos = System.nanoTime();
                if (nowNanos - lastLivenessNanos >= livenessIntervalNanos) {
                    checkLiveness();
                    lastLivenessNanos = nowNanos;
                }
            }

            // If we get here, we've hit the total timeout
            throw new RuntimeException("Request timed out after " + timeout.getSeconds() + " seconds");
        } catch (RuntimeException e) {
            // Check if process crashed during the request
            checkLiveness();
            throw e;
        } catch (ExecutionException | InterruptedException e) {
            // Check if process crashed during the request
            checkLiveness();
            throw new RuntimeException(e);
        }
    }

    private void checkLiveness() {
        RuntimeException livenessProblem = livenessCheck.get();
        if (livenessProblem != null) {
            throw livenessProblem;
        }
    }

    @VisibleForTesting
    Cursor getCursor(@Nullable List<String> cursorIds, @Nullable String sourceFileType) {
        Cursor cursor = new Cursor(null, Cursor.ROOT_VALUE);
        if (cursorIds != null) {
            for (int i = cursorIds.size() - 1; i >= 0; i--) {
                String cursorId = cursorIds.get(i);
                Object cursorObject = getObject(cursorId, sourceFileType);
                remoteObjects.put(cursorId, cursorObject);
                cursor = new Cursor(cursor, cursorObject);
            }
        }
        return cursor;
    }
}
