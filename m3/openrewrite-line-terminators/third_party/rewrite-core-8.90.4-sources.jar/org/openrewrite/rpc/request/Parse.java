/*
 * Copyright 2025 the original author or authors.
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * https://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.openrewrite.rpc.request;

import io.moderne.jsonrpc.JsonRpcMethod;
import lombok.RequiredArgsConstructor;
import lombok.Value;
import org.jspecify.annotations.Nullable;
import org.openrewrite.InMemoryExecutionContext;
import org.openrewrite.Parser;
import org.openrewrite.SourceFile;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

import static java.util.Collections.singletonList;

@Value
public class Parse implements RpcRequest {

    List<Input> inputs;

    @Nullable
    String relativeTo;

    /**
     * Optional, parser-specific options forwarded to the RPC server. The handler
     * interprets keys it recognizes and silently ignores the rest. Older clients
     * that do not send this field deserialize to {@code null}, in which case the
     * handler falls back to its process-wide defaults.
     */
    @Nullable
    Map<String, String> options;

    @Value
    public static class Input {
        @Nullable
        String text;
        Path sourcePath;
    }

    @RequiredArgsConstructor
    public static class Handler extends JsonRpcMethod<Parse> {
        private final Map<String, Object> localObjects;
        private final Supplier<List<Parser>> parsers;

        @Override
        protected Object handle(Parse request) {
            @Nullable Path relativeTo = request.getRelativeTo() != null
                    ? Paths.get(request.getRelativeTo()) : null;

            List<String> ids = new ArrayList<>();
            InMemoryExecutionContext ctx = new InMemoryExecutionContext();
            for (Input input : request.getInputs()) {
                Parser parser = findParser(input.getSourcePath());
                Parser.Input parserInput = toParserInput(input);
                SourceFile sourceFile = parser.parseInputs(
                        singletonList(parserInput), relativeTo, ctx
                ).findFirst().orElseThrow(() ->
                        new IllegalStateException("Parser returned no results for " + input.getSourcePath()));
                String id = sourceFile.getId().toString();
                localObjects.put(id, sourceFile);
                ids.add(id);
            }

            ParseResponse response = new ParseResponse();
            response.addAll(ids);
            return response;
        }

        private Parser findParser(Path sourcePath) {
            for (Parser parser : parsers.get()) {
                if (parser.accept(sourcePath)) {
                    return parser;
                }
            }
            throw new IllegalArgumentException("No parser accepts " + sourcePath);
        }

        private static Parser.Input toParserInput(Input input) {
            if (input.getText() != null) {
                return new Parser.Input(
                        input.getSourcePath(),
                        () -> new ByteArrayInputStream(input.getText().getBytes(StandardCharsets.UTF_8))
                );
            }
            return Parser.Input.fromFile(input.getSourcePath());
        }
    }
}
