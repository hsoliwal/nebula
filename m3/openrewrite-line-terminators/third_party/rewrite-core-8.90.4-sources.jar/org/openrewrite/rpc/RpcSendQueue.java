/*
 * Copyright 2025 the original author or authors.
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * https://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.openrewrite.rpc;

import org.jspecify.annotations.Nullable;
import org.openrewrite.internal.ThrowingConsumer;

import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;

import static java.util.Objects.requireNonNull;
import static org.openrewrite.rpc.RpcObjectData.ADDED_LIST_ITEM;
import static org.openrewrite.rpc.RpcObjectData.State.*;

public class RpcSendQueue {
    private final int batchSize;
    private List<RpcObjectData> batch;
    private final Consumer<List<RpcObjectData>> drain;
    private final IdentityHashMap<Object, Integer> refs;
    private final @Nullable String sourceFileType;
    private final boolean trace;

    private @Nullable Object before;

    public RpcSendQueue(int batchSize, ThrowingConsumer<List<RpcObjectData>> drain, IdentityHashMap<Object, Integer> refs,
                        @Nullable String sourceFileType, boolean trace) {
        this.batchSize = batchSize;
        this.batch = new ArrayList<>(batchSize);
        this.drain = drain;
        this.refs = refs;
        this.sourceFileType = sourceFileType;
        this.trace = trace;
    }

    public void put(RpcObjectData rpcObjectData) {
        batch.add(rpcObjectData);
        if (batch.size() == batchSize) {
            flush();
        }
    }

    /**
     * Called whenever the batch size is reached or at the end of the tree.
     * <p>
     * The batch is handed to {@code drain} directly — no defensive copy. This is
     * safe because (1) all {@code put}/{@code flush} calls happen on a single
     * traversal thread, so reassignment of {@code batch} can't race with {@code put},
     * and (2) the drain consumer (a capacity-1 {@code BlockingQueue.put}) blocks
     * until the consumer takes the list, so by the time {@code drain.accept} returns
     * there's no in-flight reader of the just-handed-off list either.
     */
    public void flush() {
        if (batch.isEmpty()) {
            return;
        }
        List<RpcObjectData> sending = batch;
        batch = new ArrayList<>(batchSize);
        drain.accept(sending);
    }

    public <T, U> void getAndSend(T parent, Function<T, @Nullable U> value) {
        getAndSend(parent, value, null);
    }

    public <T, U> void getAndSend(T parent, Function<T, @Nullable U> value, @Nullable Consumer<U> onChange) {
        U after = value.apply(parent);
        //noinspection unchecked
        U before = this.before == null ? null : value.apply((T) this.before);
        send(after, before, onChange == null || after == null ? null : () -> onChange.accept(after));
    }

    public <T, U> void getAndSendListAsRef(@Nullable T parent,
                                           Function<T, @Nullable List<U>> values,
                                           Function<? super U, ?> id,
                                           @Nullable Consumer<U> onChange) {
        getAndSendList(parent, values, id, onChange, true);
    }

    public <T, U> void getAndSendList(@Nullable T parent,
                                      Function<T, @Nullable List<U>> values,
                                      Function<? super U, ?> id,
                                      @Nullable Consumer<U> onChange) {
        getAndSendList(parent, values, id, onChange, false);
    }

    private <T, U> void getAndSendList(@Nullable T parent,
                                       Function<T, @Nullable List<U>> values,
                                       Function<? super U, ?> id,
                                       @Nullable Consumer<U> onChange,
                                       boolean asRef) {
        List<U> after = parent == null ? null : values.apply(parent);
        //noinspection unchecked
        List<U> before = this.before == null ? null : values.apply((T) this.before);
        sendList(after, before, id, onChange, asRef);
    }

    public <T> void send(@Nullable T after, @Nullable T before, @Nullable Runnable onChange) {
        Object afterVal = Reference.getValue(after);
        Object beforeVal = Reference.getValue(before);

        if (beforeVal == afterVal) {
            put(new RpcObjectData(NO_CHANGE, null, null, null, trace));
        } else if (afterVal instanceof List && beforeVal instanceof List) {
            // The concrete List implementation class (e.g. List.of vs ArrayList) is irrelevant
            // to the diff: two non-null lists always diff as CHANGE, because sendList emits
            // positions into the before list while the receiver's ADD path starts from an empty one.
            sendChange(afterVal, beforeVal, onChange);
        } else if (beforeVal == null || (afterVal != null && afterVal.getClass() != beforeVal.getClass())) {
            // Treat as ADD when before is null OR types differ (it's a new object, not a change)
            add(after, onChange);
        } else if (afterVal == null) {
            put(new RpcObjectData(DELETE, null, null, null, trace));
        } else if (after instanceof Reference) {
            // A ref-deduplicated slot is resolved by the receiver against a persistent cache whose
            // instance may be aliased by any number of other slots and source files. A CHANGE would
            // be applied to that shared instance in place, corrupting every alias, so the new value
            // is re-added instead; the refs map collapses repeats of it into ref-only ADDs.
            add(after, onChange);
        } else {
            sendChange(afterVal, beforeVal, onChange);
        }
    }

    private void sendChange(Object afterVal, Object beforeVal, @Nullable Runnable onChange) {
        RpcCodec<Object> afterCodec = RpcCodec.forInstance(afterVal, sourceFileType);
        // Without an onChange callback or codec, no property messages follow, so the
        // value must travel inline or the receiver keeps the stale object
        put(new RpcObjectData(CHANGE, getValueType(afterVal), onChange == null && afterCodec == null ? afterVal : null, null, trace));
        doChange(afterVal, beforeVal, onChange, afterCodec);
    }

    <T> void sendList(@Nullable List<T> after,
                      @Nullable List<T> before,
                      Function<? super T, ?> id,
                      @Nullable Consumer<T> onChange,
                      boolean asRef) {
        send(after, before, () -> {
            assert after != null : "A DELETE event should have been sent.";

            Map<Object, Integer> beforeIdx = putListPositions(after, before, id);

            for (T anAfter : after) {
                Integer beforePos = beforeIdx.get(id.apply(anAfter));
                Runnable onChangeRun = onChange == null ? null : () -> onChange.accept(anAfter);
                if (beforePos == null) {
                    add(asRef ? Reference.asRef(anAfter) : anAfter, onChangeRun);
                } else {
                    T aBefore = before == null ? null : before.get(beforePos);
                    if (aBefore == anAfter) {
                        put(new RpcObjectData(NO_CHANGE, null, null, null, trace));
                    } else if (asRef || aBefore == null || anAfter.getClass() != aBefore.getClass()) {
                        // Type changed - treat as ADD. Ref-deduplicated items are also always
                        // re-added rather than CHANGEd (see send()).
                        add(asRef ? Reference.asRef(anAfter) : anAfter, onChangeRun);
                    } else {
                        sendChange(anAfter, aBefore, onChangeRun);
                    }
                }
            }
        });
    }

    private <T> Map<Object, Integer> putListPositions(List<T> after, @Nullable List<T> before, Function<? super T, ?> id) {
        Map<Object, Integer> beforeIdx = new HashMap<>();
        if (before != null) {
            for (int i = 0; i < before.size(); i++) {
                beforeIdx.put(id.apply(before.get(i)), i);
            }
        }
        List<Integer> positions = new ArrayList<>();
        for (T t : after) {
            Integer beforePos = beforeIdx.get(id.apply(t));
            positions.add(beforePos == null ? ADDED_LIST_ITEM : beforePos);
        }
        put(new RpcObjectData(CHANGE, null, positions, null, trace));
        return beforeIdx;
    }

    private void add(Object after, @Nullable Runnable onChange) {
        Object afterVal = requireNonNull(Reference.getValue(after));
        Integer ref = null;
        if (after instanceof Reference) {
            if (refs.containsKey(afterVal)) {
                put(new RpcObjectData(ADD, null, null, refs.get(afterVal), trace));
                // No onChange call because the remote will be using an instance from its ref cache
                return;
            }
            ref = refs.size() + 1;
            refs.put(afterVal, ref);
        }
        RpcCodec<Object> afterCodec = RpcCodec.forInstance(afterVal, sourceFileType);
        put(new RpcObjectData(ADD, getValueType(afterVal),
                onChange == null && afterCodec == null ? afterVal : null, ref, trace));
        doChange(afterVal, null, onChange, afterCodec);
    }

    private void doChange(@Nullable Object after, @Nullable Object before, @Nullable Runnable onChange, @Nullable RpcCodec<Object> afterCodec) {
        Object lastBefore = this.before;
        this.before = before;
        try {
            if (onChange != null) {
                if (after != null) {
                    onChange.run();
                }
            } else if (afterCodec != null && after != null) {
                afterCodec.rpcSend(after, this);
            }
        } finally {
            this.before = lastBefore;
        }
    }

    private static final String JAVA_TYPE_PACKAGE = "org.openrewrite.java.tree";
    private static final String JAVA_TYPE_NAME = JAVA_TYPE_PACKAGE + ".JavaType";

    private static final ClassValue<@Nullable String> VALUE_TYPE_CACHE = new ClassValue<String>() {
        private @Nullable Class<?> javaTypeClass;
        private boolean javaTypeResolved;

        private @Nullable Class<?> getJavaTypeClass(Class<?> from) {
            if (!javaTypeResolved) {
                try {
                    javaTypeClass = Class.forName(JAVA_TYPE_NAME, false, from.getClassLoader());
                } catch (ClassNotFoundException ignored) {
                }
                javaTypeResolved = true;
            }
            return javaTypeClass;
        }

        @Override
        protected @Nullable String computeValue(Class<?> afterType) {
            Package pkg = afterType.getPackage();
            String pkgName = pkg == null ? "" : pkg.getName();
            if (afterType.isPrimitive() || afterType.isArray() || pkgName.startsWith("java.lang") ||
                // JDK value types have no codec on either side, so a valueType only buys the
                // receiver a bogus Objenesis instance it discards. Send them as scalars.
                pkgName.startsWith("java.time") || pkgName.startsWith("java.math") ||
                afterType.equals(UUID.class) || Iterable.class.isAssignableFrom(afterType) ||
                Map.class.isAssignableFrom(afterType)) {
                // A plain Map (like a Collection) is serialized structurally and needs no
                // valueType. Sending one would make the receiver treat the map as a typed
                // object and inject type/identity metadata keys (e.g. "@c"/"@ref") that leak
                // into the map as real entries, corrupting it (see RpcObjectData#getValue).
                return null;
            } else if (Enum.class.isAssignableFrom(afterType) && !JAVA_TYPE_NAME.concat("$Primitive").equals(afterType.getName())) {
                // FIXME special case for `JavaType.Primitive` here
                return null;
            }

            // If the class is a subtype of JavaType but in a different package,
            // return the superclass name instead
            Class<?> jt = getJavaTypeClass(afterType);
            if (jt != null && pkg != null && !JAVA_TYPE_PACKAGE.equals(pkg.getName()) && jt.isAssignableFrom(afterType)) {
                Class<?> superclass = afterType.getSuperclass();
                if (superclass != null && !Object.class.equals(superclass)) {
                    return superclass.getName();
                }
            }

            // Synthetic tree subclasses generated outside the org.openrewrite packages
            // -- must be reported to the remote as their real (super) type, not the proxy
            // class name, which the remote has no codec/factory for.
            if (pkg != null && !pkg.getName().startsWith("org.openrewrite")) {
                Class<?> superclass = afterType.getSuperclass();
                Package superPkg = superclass == null ? null : superclass.getPackage();
                if (superPkg != null && superPkg.getName().startsWith("org.openrewrite") && !Object.class.equals(superclass)) {
                    return superclass.getName();
                }
            }

            return afterType.getName();
        }
    };

    private static @Nullable String getValueType(@Nullable Object after) {
        return after == null ? null : VALUE_TYPE_CACHE.get(after.getClass());
    }
}
