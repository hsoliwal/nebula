/*
 * Copyright 2020 the original author or authors.
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * https://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.openrewrite;

import lombok.Getter;
import org.jspecify.annotations.Nullable;
import org.openrewrite.config.RecipeDescriptor;
import org.openrewrite.internal.InMemoryDiffEntry;
import org.openrewrite.jgit.lib.FileMode;
import org.openrewrite.marker.DeserializationError;
import org.openrewrite.marker.RecipesThatMadeChanges;
import org.openrewrite.marker.SearchResult;
import org.openrewrite.quark.Quark;
import org.openrewrite.remote.Remote;

import java.nio.file.Path;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

import static java.util.Collections.emptyList;
import static java.util.Collections.emptySet;
import static java.util.Objects.requireNonNull;
import static java.util.stream.Collectors.joining;
import static org.openrewrite.Tree.randomId;

public class Result {
    /**
     * Possible {@code null} if a new file is being created.
     */
    @Getter
    @Nullable
    private final SourceFile before;

    /**
     * Possibly {@code null} if the change results in the file being deleted.
     */
    @Getter
    @Nullable
    private final SourceFile after;

    @Getter
    private final Collection<List<Recipe>> recipes;

    /**
     * Sum of estimated time savings of all recipes that made changes to this source file.
     * This is the potential time savings because if the before and after are identical, then no time is actually saved.
     * This does not take multiple occurrences of the same change into account and just sums the estimated time savings
     * of a single occurrence for each recipe that made a change.
     */
    private final Duration potentialTimeSavings;
    private @Nullable Duration timeSavings;

    public Result(@Nullable SourceFile before, @Nullable SourceFile after, Collection<List<Recipe>> recipes) {
        this.before = before;
        this.after = after;
        this.recipes = recipes;

        Duration timeSavings = Duration.ZERO;
        // for each stack of recipes, take the last recipe in the stack (the leaf) and sum its estimated time savings
        for (List<Recipe> recipesStack : recipes) {
            if (recipesStack != null && !recipesStack.isEmpty()) {
                Duration perOccurrence = recipesStack.get(recipesStack.size() - 1).getEstimatedEffortPerOccurrence();
                if (perOccurrence != null) {
                    timeSavings = timeSavings.plus(perOccurrence);
                }
            }
        }
        this.potentialTimeSavings = timeSavings;
    }

    public Result(@Nullable SourceFile before, SourceFile after) {
        this(before, after, after.getMarkers()
                .findFirst(RecipesThatMadeChanges.class)
                .orElseGet(() -> after.getMarkers()
                        .findFirst(DeserializationError.class)
                        .map(m -> new RecipesThatMadeChanges(randomId(), emptyList()))
                        .orElseThrow(() -> new UnknownSourceFileChangeException(
                                after,
                                explainWhatChanged(before, after)
                        )))
                .getRecipes());
    }

    private static String explainWhatChanged(@Nullable SourceFile before, SourceFile after) {
        if (before == null) {
            return String.format("A new file %s was generated but no recipe reported generating it. This is likely a bug in OpenRewrite itself.",
                    after.getSourcePath());
        }
        Map<UUID, Tree> beforeTrees = new HashMap<>();
        new TreeVisitor<Tree, Integer>() {
            @Override
            public @Nullable Tree visit(@Nullable Tree tree, Integer integer) {
                if (tree != null) {
                    beforeTrees.put(tree.getId(), tree);
                }
                return super.visit(tree, integer);
            }
        }.visit(before, 0);

        SourceFile changesMarked = (SourceFile) new TreeVisitor<Tree, Integer>() {
            @Override
            public @Nullable Tree visit(@Nullable Tree tree, Integer p) {
                if (tree != null &&
                    beforeTrees.get(tree.getId()) != tree &&
                    !subtreeChanged(tree, beforeTrees)) {
                    return SearchResult.found(tree);
                }
                return super.visit(tree, p);
            }
        }.visitNonNull(after, 0);

        String diff = diff(before.printAllTrimmed(), changesMarked.printAllTrimmed(), after.getSourcePath());
        return "The following diff highlights the places where unexpected changes were made:\n" +
               Arrays.stream(requireNonNull(diff).split("\n"))
                       .map(l -> "  " + l)
                       .collect(joining("\n"));
    }

    private static boolean subtreeChanged(Tree root, Map<UUID, Tree> beforeTrees) {
        return new TreeVisitor<Tree, AtomicBoolean>() {
            @Override
            public @Nullable Tree visit(@Nullable Tree tree, AtomicBoolean changed) {
                if (tree != null && tree != root) {
                    if (beforeTrees.get(tree.getId()) != tree) {
                        changed.set(true);
                    }
                }
                return super.visit(tree, changed);
            }
        }.reduce(root, new AtomicBoolean(false)).get();
    }

    /**
     * Sum of estimated time savings of all recipes that made changes to this source file.
     * This does not take multiple occurrences of the same change into account and just sums the estimated time savings
     * of a single occurrence for each recipe that made a change.
     */
    public Duration getTimeSavings() {
        if (timeSavings == null) {
            if (potentialTimeSavings.isZero() || isLocalAndHasNoChanges(before, after)) {
                timeSavings = Duration.ZERO;
            } else {
                timeSavings = potentialTimeSavings;
            }
        }
        return timeSavings;
    }

    /**
     * Return a list of recipes that have made changes as a hierarchy of descriptors.
     * The method transforms the flat, stack-based representation into descriptors where children are grouped under their common parents.
     */
    public List<RecipeDescriptor> getRecipeDescriptorsThatMadeChanges() {
        List<RecipeDescriptor> recipesToDisplay = new ArrayList<>();

        for (List<Recipe> currentStack : recipes) {
            Recipe root;
            if (currentStack.size() > 1) {
                // The first recipe is typically an Environment.CompositeRecipe and should not be included in the list of RecipeDescriptors
                root = currentStack.get(1);
            } else {
                root = currentStack.get(0);
            }
            RecipeDescriptor rootDescriptor = root.getDescriptor().withRecipeList(new ArrayList<>());

            RecipeDescriptor index;
            if (recipesToDisplay.contains(rootDescriptor)) {
                index = recipesToDisplay.get(recipesToDisplay.indexOf(rootDescriptor));
            } else {
                recipesToDisplay.add(rootDescriptor);
                index = rootDescriptor;
            }

            for (int i = 2; i < currentStack.size(); i++) {
                RecipeDescriptor nextDescriptor = currentStack.get(i).getDescriptor().withRecipeList(new ArrayList<>());
                if (index.getRecipeList().contains(nextDescriptor)) {
                    index = index.getRecipeList().get(index.getRecipeList().indexOf(nextDescriptor));
                } else {
                    index.getRecipeList().add(nextDescriptor);
                    index = nextDescriptor;
                }
            }
        }
        return recipesToDisplay;
    }

    /**
     * @return Git-style patch diff representing the changes to this compilation unit.
     */
    public String diff() {
        return diff(null);
    }

    /**
     * @param relativeTo Optional relative path that is used to relativize file paths of reported differences.
     * @return Git-style patch diff representing the changes to this compilation unit.
     */
    public String diff(@Nullable Path relativeTo) {
        return diff(relativeTo, null);
    }

    public String diff(@Nullable Path relativeTo, PrintOutputCapture.@Nullable MarkerPrinter markerPrinter) {
        return diff(relativeTo, markerPrinter, false);
    }

    @Incubating(since = "7.34.0")
    public String diff(@Nullable Path relativeTo, PrintOutputCapture.@Nullable MarkerPrinter markerPrinter, @Nullable Boolean ignoreAllWhitespace) {
        return diff(relativeTo, markerPrinter, ignoreAllWhitespace, false);
    }

    @Incubating(since = "8.69.0")
    public String diff(@Nullable Path relativeTo, PrintOutputCapture.@Nullable MarkerPrinter markerPrinter, @Nullable Boolean ignoreAllWhitespace, boolean binaryPatch) {
        Set<Recipe> recipeSet = new HashSet<>(recipes.size());
        for (List<Recipe> rs : recipes) {
            if (!rs.isEmpty()) {
                recipeSet.add(rs.get(0));
            }
        }

        try (InMemoryDiffEntry diffEntry = new InMemoryDiffEntry(
                before,
                after,
                relativeTo,
                markerPrinter,
                recipeSet,
                binaryPatch
        )) {
            return diffEntry.getDiff(ignoreAllWhitespace);
        }
    }

    public static @Nullable String diff(String before, String after, Path path) {
        String diff = null;
        try (InMemoryDiffEntry diffEntry = new InMemoryDiffEntry(
                path,
                path,
                null,
                before,
                after,
                emptySet(),
                FileMode.REGULAR_FILE,
                FileMode.REGULAR_FILE
        )) {
            diff = diffEntry.getDiff(Boolean.FALSE);
        } catch (Exception ignored) {
        }
        return diff;
    }

    @Override
    public String toString() {
        return diff();
    }

    public static boolean isLocalAndHasNoChanges(@Nullable SourceFile before, @Nullable SourceFile after) {
        try {
            if (before == after) {
                return true;
            }
            if (before == null || after == null) {
                return false;
            }
            // Remote source files are fetched on `printAll`, let's avoid that cost.
            if (before instanceof Remote || after instanceof Remote) {
                return false;
            }
            // Quarks don't support printAll(); compare by source path instead
            if (before instanceof Quark && after instanceof Quark) {
                return before.getSourcePath().equals(after.getSourcePath());
            }
            return before.printAll().equals(after.printAll());
        } catch (Exception e) {
            return false;
        }
    }
}
