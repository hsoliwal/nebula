/*
 * Copyright 2023 the original author or authors.
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * https://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.openrewrite.java;

import lombok.Value;
import org.openrewrite.Cursor;
import org.openrewrite.internal.PropertyPlaceholderHelper;
import org.openrewrite.java.internal.grammar.TemplateParameterParser;
import org.openrewrite.java.internal.grammar.TemplateParameterParser.TypedPatternContext;
import org.openrewrite.java.internal.template.TemplateParameter;
import org.openrewrite.java.internal.template.TypeParameter;
import org.openrewrite.java.search.SemanticallyEqual;
import org.openrewrite.java.tree.*;
import org.openrewrite.marker.Markers;

import java.util.*;

import static java.util.Collections.emptyList;
import static java.util.Collections.singleton;
import static org.openrewrite.Tree.randomId;

class JavaTemplateSemanticallyEqual extends SemanticallyEqual {

    @Value
    static class TemplateMatchResult {
        boolean match;
        List<J> matchedParameters;
    }

    static TemplateMatchResult matchesTemplate(JavaTemplate template, Cursor input) {
        JavaCoordinates coordinates;
        if (input.getValue() instanceof Expression) {
            coordinates = ((Expression) input.getValue()).getCoordinates().replace();
        } else if (input.getValue() instanceof Statement) {
            coordinates = ((Statement) input.getValue()).getCoordinates().replace();
        } else {
            throw new IllegalArgumentException("Only expressions and statements can be matched against a template: " + input.getClass());
        }

        J[] parameters = createTemplateParameters(template.getCode(), template.getGenericTypes());
        try {
            J templateTree = template.applyWithoutFormatting(input, coordinates, (Object[]) parameters);
            return matchTemplate(templateTree, input);
        } catch (RuntimeException e) {
            // FIXME this is just a workaround, as template matching finds many new corner cases in `JavaTemplate` which we need to fix
            return new TemplateMatchResult(false, emptyList());
        }
    }

    private static J[] createTemplateParameters(String code, Set<String> genericTypes) {
        PropertyPlaceholderHelper propertyPlaceholderHelper = new PropertyPlaceholderHelper(
                "#{", "}", null);

        Map<String, JavaType.GenericTypeVariable> generics = TypeParameter.parseGenericTypes(genericTypes);
        List<J> parameters = new ArrayList<>();
        String substituted = code;
        Map<String, String> typedPatternByName = new HashMap<>();
        while (true) {
            String previous = substituted;
            substituted = propertyPlaceholderHelper.replacePlaceholders(substituted, key -> {
                String s;
                if (!key.isEmpty()) {
                    TemplateParameterParser.MatcherPatternContext ctx = TypeParameter.parser(key).matcherPattern();
                    if (ctx.typedPattern() == null) {
                        String paramName = ctx.parameterName().Identifier().getText();
                        s = typedPatternByName.get(paramName);
                        if (s == null) {
                            throw new IllegalArgumentException("The parameter " + paramName + " must be defined before it is referenced.");
                        }
                    } else {
                        TypedPatternContext typedPattern = ctx.typedPattern();
                        JavaType type = typedParameter(key, typedPattern, generics);
                        s = TypeUtils.toString(type);

                        String name = null;
                        if (typedPattern.parameterName() != null) {
                            name = typedPattern.parameterName().Identifier().getText();
                            typedPatternByName.put(name, s);
                        }

                        Markers markers = Markers.build(singleton(new TemplateParameter(randomId(), type, name)));
                        parameters.add(new J.Empty(randomId(), Space.EMPTY, markers));
                    }
                } else {
                    throw new IllegalArgumentException("Only typed placeholders are allowed.");
                }

                return s;
            });

            if (previous.equals(substituted)) {
                break;
            }
        }

        return parameters.toArray(new J[0]);
    }

    private static JavaType typedParameter(String key, TypedPatternContext typedPattern, Map<String, JavaType.GenericTypeVariable> generics) {
        String matcherName = typedPattern.patternType().matcherName().Identifier().getText();
        if ("any".equals(matcherName)) {
            return TypeParameter.toJavaType(typedPattern.patternType().type(), generics);
        } else if ("anyArray".equals(matcherName)) {
            return new JavaType.Array(null, TypeParameter.toJavaType(typedPattern.patternType().type(), generics), null);
        } else {
            throw new IllegalArgumentException("Unsupported template matcher '" + key + "'");
        }
    }

    private static TemplateMatchResult matchTemplate(J templateTree, Cursor cursor) {
        if (templateTree == cursor.getValue()) {
            // When `JavaTemplate#apply()` returns the input itself, it could not be matched
            return new TemplateMatchResult(false, emptyList());
        }

        JavaTemplateSemanticallyEqualVisitor semanticallyEqualVisitor = new JavaTemplateSemanticallyEqualVisitor();
        semanticallyEqualVisitor.visit(templateTree, cursor.getValue(), cursor.getParentOrThrow());
        return new TemplateMatchResult(semanticallyEqualVisitor.isEqual(), new ArrayList<>(
                semanticallyEqualVisitor.matchedParameters.keySet()));
    }

    @SuppressWarnings("ConstantConditions")
    private static class JavaTemplateSemanticallyEqualVisitor extends SemanticallyEqualVisitor {
        final Map<J, String> matchedParameters = new LinkedHashMap<>();

        public JavaTemplateSemanticallyEqualVisitor() {
            super(true);
        }

        private boolean matchTemplateParameterPlaceholder(J.Empty empty, J j) {
            if (j instanceof TypedTree) {
                if (j instanceof J.Primitive || j instanceof J.Identifier && ((J.Identifier) j).getFieldType() == null) {
                    // don't match types, only expressions
                    return false;
                }
                TemplateParameter marker = (TemplateParameter) empty.getMarkers().getMarkers().get(0);

                if (marker.getName() != null) {
                    for (Map.Entry<J, String> matchedParameter : matchedParameters.entrySet()) {
                        if (matchedParameter.getValue().equals(marker.getName())) {
                            return SemanticallyEqual.areEqual(matchedParameter.getKey(), j);
                        }
                    }
                }

                if (isAssignableTo(marker.getType(), ((TypedTree) j).getType())) {
                    matchedParameters.put(j, marker.getName());
                    return true;
                }
            }
            return false;
        }

        @Override
        public J.Empty visitEmpty(J.Empty empty, J j) {
            if (isEqual.get()) {
                if (isTemplateParameterPlaceholder(empty)) {
                    isEqual.set(matchTemplateParameterPlaceholder(empty, j));
                    return empty;
                }
                if (!(j instanceof J.Empty)) {
                    isEqual.set(false);
                    return empty;
                }

                J.Empty compareTo = (J.Empty) j;
                if (nullMissMatch(empty.getType(), compareTo.getType())) {
                    isEqual.set(false);
                    return empty;
                }
            }
            return empty;
        }

        private static boolean isTemplateParameterPlaceholder(J.Empty empty) {
            Markers markers = empty.getMarkers();
            return markers.getMarkers().size() == 1 && markers.getMarkers().get(0) instanceof TemplateParameter;
        }

        @Override
        protected boolean isOfType(JavaType target, JavaType source) {
            return TypeUtils.isAssignableTo(target, source, TypeUtils.ComparisonContext.INFER);
        }

        @Override
        protected boolean isAssignableTo(JavaType to, JavaType from) {
            return TypeUtils.isAssignableTo(to, from, TypeUtils.ComparisonContext.INFER);
        }

        @Override
        public J.MemberReference visitMemberReference(J.MemberReference memberRef, J j) {
            if (isEqual.get() && j instanceof J.MemberReference) {
                J.MemberReference compareTo = (J.MemberReference) j;
                // When the template's containing expression is a template parameter placeholder,
                // always visit it to match against the actual containing expression.
                // The base class only visits containing when it's a J.Identifier or J.FieldAccess
                // with a fieldType, which misses literals and other expression types.
                if (memberRef.getContaining() instanceof J.Empty &&
                    isTemplateParameterPlaceholder((J.Empty) memberRef.getContaining())) {
                    if (!memberRef.getReference().getSimpleName().equals(compareTo.getReference().getSimpleName())) {
                        isEqual.set(false);
                        return memberRef;
                    }
                    visit(memberRef.getContaining(), compareTo.getContaining());
                    return memberRef;
                }
            }
            return super.visitMemberReference(memberRef, j);
        }

        @Override
        public J.MethodInvocation visitMethodInvocation(J.MethodInvocation template, J j) {
            if (!isEqual.get()) {
                return template;
            }
            if (!(j instanceof J.MethodInvocation)) {
                isEqual.set(false);
                return template;
            }

            J.MethodInvocation actual = (J.MethodInvocation) j;
            JavaType.Method templateMethod = template.getMethodType();

            // Check if this is a varargs method with a placeholder at varargs position
            if (templateMethod != null &&
                templateMethod.hasFlags(Flag.Varargs) &&
                hasVarargsPlaceholder(template)) {

                isEqual.set(matchWithVarargs(template, actual));
                return template;
            }

            return super.visitMethodInvocation(template, j);
        }

        private boolean hasVarargsPlaceholder(J.MethodInvocation template) {
            List<JRightPadded<Expression>> args = template.getPadding().getArguments().getPadding().getElements();
            if (args.isEmpty()) {
                return false;
            }
            JRightPadded<Expression> lastArg = args.get(args.size() - 1);
            if (!(lastArg.getElement() instanceof J.Empty)) {
                return false;
            }
            J.Empty empty = (J.Empty) lastArg.getElement();
            if (!isTemplateParameterPlaceholder(empty)) {
                return false;
            }
            TemplateParameter param = (TemplateParameter) empty.getMarkers().getMarkers().get(0);
            return param.getType() instanceof JavaType.Array;
        }

        private boolean matchWithVarargs(J.MethodInvocation template, J.MethodInvocation actual) {
            JavaType.Method templateMethod = template.getMethodType();
            JavaType.Method actualMethod = actual.getMethodType();

            // Check method name matches
            if (!template.getSimpleName().equals(actual.getSimpleName())) {
                return false;
            }

            // Check method types are present
            if (templateMethod == null || actualMethod == null) {
                return false;
            }

            // Check return type is assignable
            if (!isAssignableTo(templateMethod.getReturnType(), actualMethod.getReturnType())) {
                return false;
            }

            // Check static flag compatibility
            boolean templateStatic = templateMethod.hasFlags(Flag.Static);
            boolean actualStatic = actualMethod.hasFlags(Flag.Static);
            if (templateStatic != actualStatic) {
                return false;
            }

            // Check select expression
            if (templateStatic) {
                JavaType.FullyQualified templateDeclaringType = templateMethod.getDeclaringType();
                JavaType.FullyQualified actualDeclaringType = actualMethod.getDeclaringType();
                if (!isAssignableTo(
                        templateDeclaringType instanceof JavaType.Parameterized ?
                                ((JavaType.Parameterized) templateDeclaringType).getType() : templateDeclaringType,
                        actualDeclaringType instanceof JavaType.Parameterized ?
                                ((JavaType.Parameterized) actualDeclaringType).getType() : actualDeclaringType)) {
                    return false;
                }
            } else {
                if (nullMissMatch(template.getSelect(), actual.getSelect())) {
                    return false;
                }
                if (template.getSelect() != null && actual.getSelect() != null) {
                    visit(template.getSelect(), actual.getSelect());
                    if (!isEqual.get()) {
                        return false;
                    }
                }
            }

            List<JRightPadded<Expression>> templateArgs = template.getPadding().getArguments().getPadding().getElements();
            List<JRightPadded<Expression>> actualArgs = actual.getPadding().getArguments().getPadding().getElements();

            // Handle the case where actual has "no arguments" represented as a single J.Empty
            boolean actualHasNoArgs = actualArgs.isEmpty() ||
                    (actualArgs.size() == 1 && actualArgs.get(0).getElement() instanceof J.Empty &&
                            !isTemplateParameterPlaceholder((J.Empty) actualArgs.get(0).getElement()));
            if (actualHasNoArgs) {
                actualArgs = emptyList();
            }

            int fixedArgCount = templateArgs.size() - 1; // All except the last varargs placeholder

            // Check actual has at least the fixed arguments
            if (actualArgs.size() < fixedArgCount) {
                return false;
            }

            // Match fixed arguments
            for (int i = 0; i < fixedArgCount; i++) {
                visit(templateArgs.get(i).getElement(), actualArgs.get(i).getElement());
                if (!isEqual.get()) {
                    return false;
                }
            }

            // Get the varargs placeholder and its element type
            J.Empty varargsPlaceholder = (J.Empty) templateArgs.get(fixedArgCount).getElement();
            TemplateParameter param = (TemplateParameter) varargsPlaceholder.getMarkers().getMarkers().get(0);
            JavaType.Array arrayType = (JavaType.Array) param.getType();
            JavaType elementType = arrayType.getElemType();

            // Collect varargs elements
            List<Expression> varargsElements = new ArrayList<>();
            for (int i = fixedArgCount; i < actualArgs.size(); i++) {
                Expression actualArg = actualArgs.get(i).getElement();

                // Handle case where explicit array is passed to varargs position
                if (i == fixedArgCount && actualArgs.size() == fixedArgCount + 1) {
                    JavaType actualArgType = actualArg.getType();
                    if (actualArgType instanceof JavaType.Array) {
                        // Single array argument passed to varargs - match it directly
                        if (isAssignableTo(arrayType, actualArgType)) {
                            varargsElements.add(actualArg);
                            break;
                        }
                    }
                }

                // Check each varargs element is assignable to the element type
                if (actualArg instanceof TypedTree) {
                    JavaType actualArgType = ((TypedTree) actualArg).getType();
                    if (!isAssignableTo(elementType, actualArgType)) {
                        return false;
                    }
                    varargsElements.add(actualArg);
                } else {
                    return false;
                }
            }

            // Build the J.NewArray representing the matched varargs
            J.NewArray currentVarargs = buildVarargsArray(varargsElements, arrayType);

            // Check for named parameter reuse
            if (param.getName() != null) {
                for (Map.Entry<J, String> entry : matchedParameters.entrySet()) {
                    if (param.getName().equals(entry.getValue())) {
                        // Named parameter already matched - verify current matches previous
                        return SemanticallyEqual.areEqual(entry.getKey(), currentVarargs);
                    }
                }
            }

            // Register the match
            matchedParameters.put(currentVarargs, param.getName());
            return true;
        }

        private J.NewArray buildVarargsArray(List<Expression> elements, JavaType.Array arrayType) {
            JContainer<Expression> initializer = null;
            if (!elements.isEmpty()) {
                List<JRightPadded<Expression>> paddedElements = new ArrayList<>(elements.size());
                for (Expression element : elements) {
                    paddedElements.add(JRightPadded.build(element));
                }
                initializer = JContainer.build(paddedElements);
            }
            return new J.NewArray(
                    randomId(),
                    Space.EMPTY,
                    Markers.EMPTY,
                    null, // typeExpression - not needed for matching purposes
                    emptyList(), // dimensions
                    initializer,
                    arrayType
            );
        }
    }
}
