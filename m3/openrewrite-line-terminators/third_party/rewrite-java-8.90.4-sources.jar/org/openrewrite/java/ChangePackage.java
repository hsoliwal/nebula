/*
 * Copyright 2020 the original author or authors.
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * https://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.openrewrite.java;

import lombok.EqualsAndHashCode;
import lombok.Value;
import lombok.With;
import org.jspecify.annotations.Nullable;
import org.openrewrite.*;
import org.openrewrite.internal.ListUtils;
import org.openrewrite.java.internal.PackageNameUtils;
import org.openrewrite.java.marker.JavaSourceSet;
import org.openrewrite.java.tree.*;
import org.openrewrite.marker.SearchResult;
import org.openrewrite.trait.Reference;

import java.nio.file.Paths;
import java.util.*;

import static java.util.Objects.requireNonNull;
import static org.openrewrite.Tree.randomId;

/**
 * A recipe that will rename a package name in package statements, imports, and fully-qualified types (see: NOTE).
 * <p>
 * NOTE: Does not currently transform all possible type references, and accomplishing this would be non-trivial.
 * For example, a method invocation select might refer to field {@code A a} whose type has now changed to {@code A2}, and so the type
 * on the select should change as well. But how do we identify the set of all method selects which refer to {@code a}? Suppose
 * it were prefixed like {@code this.a}, or {@code MyClass.this.a}, or indirectly via a separate method call like {@code getA()} where {@code getA()}
 * is defined on the super class.
 */
@Value
@EqualsAndHashCode(callSuper = false)
public class ChangePackage extends Recipe {
    @Option(displayName = "Old package name",
            description = "The package name to replace.",
            example = "com.yourorg.foo")
    String oldPackageName;

    @Option(displayName = "New package name",
            description = "New package name to replace the old package name with.",
            example = "com.yourorg.bar")
    String newPackageName;

    @With
    @Option(displayName = "Recursive",
            description = "Recursively change subpackage names. Defaults to `false`, renaming only types " +
                          "directly in `oldPackageName`; set to `true` to also rename types in its subpackages.",
            required = false)
    @Nullable
    Boolean recursive;

    private boolean isRecursive() {
        return Boolean.TRUE.equals(recursive);
    }

    @Override
    public String getInstanceNameSuffix() {
        return String.format("`%s` to `%s`", oldPackageName, newPackageName);
    }

    String displayName = "Rename package name";

    String description = "A recipe that will rename a package name in package statements, imports, and fully-qualified types.";

    @Override
    public Validated<Object> validate() {
        return Validated.none()
                .and(Validated.notBlank("oldPackageName", oldPackageName))
                .and(Validated.required("newPackageName", newPackageName));
    }

    @Override
    public TreeVisitor<?, ExecutionContext> getVisitor() {
        TreeVisitor<?, ExecutionContext> condition = new TreeVisitor<Tree, ExecutionContext>() {
            @Override
            public @Nullable Tree preVisit(@Nullable Tree tree, ExecutionContext ctx) {
                stopAfterPreVisit();
                boolean recursive = isRecursive();
                String recursivePackageNamePrefix = oldPackageName + ".";
                if (tree instanceof JavaSourceFile) {
                    JavaSourceFile cu = (JavaSourceFile) tree;
                    if (cu.getPackageDeclaration() != null) {
                        String original = PackageNameUtils.getPackageName(cu.getPackageDeclaration());
                        if (original.equals(oldPackageName) || recursive && original.startsWith(recursivePackageNamePrefix)) {
                            return SearchResult.found(cu);
                        }
                    }
                    for (J.Import anImport : cu.getImports()) {
                        String importedPackage = anImport.getPackageName();
                        if (importedPackage.equals(oldPackageName) || recursive && importedPackage.startsWith(recursivePackageNamePrefix)) {
                            return SearchResult.found(cu);
                        }
                    }
                    for (JavaType type : cu.getTypesInUse().getTypesInUse()) {
                        if (type instanceof JavaType.FullyQualified) {
                            String packageName = ((JavaType.FullyQualified) type).getPackageName();
                            if (packageName.equals(oldPackageName) || recursive && packageName.startsWith(recursivePackageNamePrefix)) {
                                return SearchResult.found(cu);
                            }
                        }
                    }
                    // Fully qualified documentation-comment references are excluded from TypesInUse's
                    // import-retention set (they don't affect imports), but they still need package renaming.
                    if (cu.getTypesInUse().hasDocReferenceInPackage(oldPackageName, recursive)) {
                        return SearchResult.found(cu);
                    }
                } else if (tree instanceof SourceFileWithReferences) {
                    SourceFileWithReferences cu = (SourceFileWithReferences) tree;
                    PackageMatcher matcher = new PackageMatcher(oldPackageName, recursive);
                    for (Reference ref : cu.getReferences().getReferences()) {
                        if (matcher.matchesReference(ref)) {
                            return SearchResult.found(cu);
                        }
                    }
                }
                return tree;
            }
        };

        return Preconditions.check(condition, new TreeVisitor<Tree, ExecutionContext>() {
            @Override
            public boolean isAcceptable(SourceFile sourceFile, ExecutionContext ctx) {
                return sourceFile instanceof JavaSourceFile || sourceFile instanceof SourceFileWithReferences;
            }

            @Override
            public @Nullable Tree preVisit(@Nullable Tree tree, ExecutionContext ctx) {
                stopAfterPreVisit();
                if (tree instanceof JavaSourceFile) {
                    return new JavaChangePackageVisitor().visit(tree, ctx, requireNonNull(getCursor().getParent()));
                } else if (tree instanceof SourceFileWithReferences) {
                    SourceFileWithReferences sourceFile = (SourceFileWithReferences) tree;
                    SourceFileWithReferences.References references = sourceFile.getReferences();
                    PackageMatcher matcher = new PackageMatcher(oldPackageName, isRecursive());
                    Map<Tree, List<Reference>> matches = new HashMap<>();
                    for (Reference ref : references.findMatches(matcher)) {
                        matches.computeIfAbsent(ref.getTree(), k -> new java.util.ArrayList<>()).add(ref);
                    }
                    return new ReferenceChangePackageVisitor(matches, matcher.createRenamer(newPackageName)).visit(tree, ctx, requireNonNull(getCursor().getParent()));
                }
                return tree;
            }
        });
    }

    private class JavaChangePackageVisitor extends JavaVisitor<ExecutionContext> {
        private static final String RENAME_TO_KEY = "renameTo";
        private static final String RENAME_FROM_KEY = "renameFrom";

        private final Map<JavaType, JavaType> oldNameToChangedType = new IdentityHashMap<>();
        private final JavaType.Class newPackageType = JavaType.ShallowClass.build(newPackageName);

        @Override
        public J visitFieldAccess(J.FieldAccess fieldAccess, ExecutionContext ctx) {
            J f = super.visitFieldAccess(fieldAccess, ctx);

            if (!((J.FieldAccess) f).isFullyQualifiedClassReference(oldPackageName)) {
                return f;
            }
            Cursor parent = getCursor().getParent();
            if (parent == null) {
                return f;
            }
            if (parent.getValue() instanceof J.FieldAccess) {
                J.FieldAccess enclosing = (J.FieldAccess) parent.getValue();
                if (enclosing.isFullyQualifiedClassReference(newPackageName)) {
                    // Already rewritten to the new package.
                    return f;
                }
                if (!isRecursive() && !namesTypeDirectlyInOldPackage(enclosing)) {
                    // Leading segments of a subpackage-qualified name such as oldPackageName.sub.Type.
                    return f;
                }
            }
            return TypeTree.build(((JavaType.FullyQualified) newPackageType).getFullyQualifiedName())
                    .withPrefix(f.getPrefix());
        }

        /**
         * Whether the name enclosing this occurrence of {@code oldPackageName} is a type declared
         * directly in it, rather than a subpackage. Uses the same leading-capital convention as
         * {@link PackageMatcher} where type attribution is unavailable.
         */
        private boolean namesTypeDirectlyInOldPackage(J.FieldAccess enclosing) {
            JavaType.FullyQualified fq = TypeUtils.asFullyQualified(enclosing.getType());
            if (fq != null) {
                return oldPackageName.equals(fq.getPackageName());
            }
            String nextSegment = enclosing.getSimpleName();
            return "*".equals(nextSegment) ||
                   !nextSegment.isEmpty() && Character.isUpperCase(nextSegment.charAt(0));
        }

        @Override
        public J visitPackage(J.Package pkg, ExecutionContext ctx) {
            String original = PackageNameUtils.getPackageName(pkg);
            getCursor().putMessageOnFirstEnclosing(JavaSourceFile.class, RENAME_FROM_KEY, original);

            pkg = pkg.withAnnotations(ListUtils.map(pkg.getAnnotations(), a -> visitAndCast(a, ctx)));

            if (original.equals(oldPackageName)) {
                getCursor().putMessageOnFirstEnclosing(JavaSourceFile.class, RENAME_TO_KEY, newPackageName);

                if (!newPackageName.isEmpty()) {
                    pkg = JavaTemplate.builder(newPackageName).contextSensitive().build().apply(getCursor(), pkg.getCoordinates().replace());
                } else {
                    // Covers unlikely scenario where the package is removed.
                    getCursor().putMessageOnFirstEnclosing(JavaSourceFile.class, "UPDATE_PREFIX", true);
                    pkg = null;
                }
            } else if (isTargetRecursivePackageName(original)) {
                String changingTo = getNewPackageName(original);
                getCursor().putMessageOnFirstEnclosing(JavaSourceFile.class, RENAME_TO_KEY, changingTo);
                pkg = JavaTemplate.builder(changingTo)
                        .contextSensitive()
                        .build()
                        .apply(getCursor(), pkg.getCoordinates().replace());
            }
            //noinspection ConstantConditions
            return pkg;
        }

        @Override
        public J visitImport(J.Import _import, ExecutionContext ctx) {
            // Polls message before calling super to change the prefix of the first import if applicable.
            Boolean updatePrefix = getCursor().pollNearestMessage("UPDATE_PREFIX");
            if (updatePrefix != null && updatePrefix) {
                _import = _import.withPrefix(Space.EMPTY);
            }
            return super.visitImport(_import, ctx);
        }

        @Override
        public J visitClassDeclaration(J.ClassDeclaration classDecl, ExecutionContext ctx) {
            J c = super.visitClassDeclaration(classDecl, ctx);

            Boolean updatePrefix = getCursor().pollNearestMessage("UPDATE_PREFIX");
            if (updatePrefix != null && updatePrefix) {
                c = c.withPrefix(Space.EMPTY);
            }
            return c;
        }

        @Override
        public @Nullable JavaType visitType(@Nullable JavaType javaType, ExecutionContext ctx) {
            return updateType(javaType);
        }

        @Override
        public J postVisit(J tree, ExecutionContext ctx) {
            J j = super.postVisit(tree, ctx);
            if (j instanceof J.MethodDeclaration) {
                J.MethodDeclaration m = (J.MethodDeclaration) j;
                JavaType.Method mt = updateType(m.getMethodType());
                return m.withMethodType(mt).withName(m.getName().withType(mt));
            } else if (j instanceof J.MethodInvocation) {
                J.MethodInvocation m = (J.MethodInvocation) j;
                JavaType.Method mt = updateType(m.getMethodType());
                return m.withMethodType(mt).withName(m.getName().withType(mt));
            } else if (j instanceof J.NewClass) {
                J.NewClass n = (J.NewClass) j;
                return n.withConstructorType(updateType(n.getConstructorType()));
            } else if (j instanceof TypedTree) {
                return ((TypedTree) j).withType(updateType(((TypedTree) j).getType()));
            } else if (j instanceof JavaSourceFile) {
                JavaSourceFile sf = (JavaSourceFile) j;

                String changingTo = getCursor().getNearestMessage(RENAME_TO_KEY);
                if (changingTo != null) {
                    String path = ((SourceFile) sf).getSourcePath().toString().replace('\\', '/');
                    String changingFrom = getCursor().getMessage(RENAME_FROM_KEY);
                    assert changingFrom != null;
                    sf = ((SourceFile) sf).withSourcePath(Paths.get(path.replaceFirst(
                            changingFrom.replace('.', '/'),
                            changingTo.replace('.', '/')
                    )));

                    for (J.Import anImport : sf.getImports()) {
                        if (anImport.getPackageName().equals(changingTo) && !anImport.isStatic()) {
                            // Skip removal for nested class imports - they still need the import even in the same package
                            JavaType.FullyQualified fq = TypeUtils.asFullyQualified(anImport.getQualid().getType());
                            if (fq != null && fq.getOwningClass() != null) {
                                continue;
                            }
                            sf = (JavaSourceFile) new RemoveImport<ExecutionContext>(anImport.getTypeName(), true)
                                    .visitNonNull(sf, ctx, getCursor().getParentTreeCursor());
                        }
                    }
                }

                // Expand changed star imports that would create ambiguity with other star imports
                sf = maybeExpandStarImport(sf, newPackageName, oldPackageName, ctx);
                if (changingTo != null && !changingTo.equals(newPackageName)) {
                    String oldSubPkg = oldPackageName + changingTo.substring(newPackageName.length());
                    sf = maybeExpandStarImport(sf, changingTo, oldSubPkg, ctx);
                }
                if (isRecursive()) {
                    for (J.Import anImport : sf.getImports()) {
                        if (!anImport.isStatic() && "*".equals(anImport.getQualid().getSimpleName())) {
                            String pkg = anImport.getPackageName();
                            if (pkg.startsWith(newPackageName + ".")) {
                                String oldPkg = oldPackageName + pkg.substring(newPackageName.length());
                                sf = maybeExpandStarImport(sf, pkg, oldPkg, ctx);
                            }
                        }
                    }
                }

                j = sf;
            }
            //noinspection DataFlowIssue
            return j;
        }

        /**
         * If a star import for {@code changedPackage} exists alongside other star imports,
         * and types from {@code changedPackage} share simple names with types from those
         * other packages, expand the star import into explicit imports to avoid ambiguity.
         *
         * @param changedPackage the new package name (after rename)
         * @param originalPackage the old package name (before rename), used to find types on classpath
         */
        private JavaSourceFile maybeExpandStarImport(JavaSourceFile sf, String changedPackage, String originalPackage, ExecutionContext ctx) {
            J.Import changedStarImport = null;
            Set<String> otherStarPackages = new LinkedHashSet<>();
            for (J.Import anImport : sf.getImports()) {
                if (anImport.isStatic() || !"*".equals(anImport.getQualid().getSimpleName())) {
                    continue;
                }
                if (anImport.getPackageName().equals(changedPackage)) {
                    changedStarImport = anImport;
                } else {
                    otherStarPackages.add(anImport.getPackageName());
                }
            }

            if (changedStarImport == null || otherStarPackages.isEmpty()) {
                return sf;
            }

            if (!hasAmbiguity(sf, changedPackage, originalPackage, otherStarPackages, ctx)) {
                return sf;
            }

            // Collect simple names of types used from the changed package
            Set<String> usedFromChangedPackage = new TreeSet<>();
            for (JavaType type : sf.getTypesInUse().getTypesInUse()) {
                if (type instanceof JavaType.FullyQualified) {
                    JavaType.FullyQualified fq = (JavaType.FullyQualified) type;
                    if (fq.getPackageName().equals(changedPackage)) {
                        usedFromChangedPackage.add(fq.getClassName());
                    }
                }
            }

            if (usedFromChangedPackage.isEmpty()) {
                return sf;
            }

            // Expand the changed star import into explicit imports for used types
            J.Import starImport = changedStarImport;
            return sf.withImports(ListUtils.flatMap(sf.getImports(), anImport -> {
                if (anImport == starImport) {
                    List<J.Import> expanded = new ArrayList<>(usedFromChangedPackage.size());
                    int i = 0;
                    for (String simpleName : usedFromChangedPackage) {
                        J.FieldAccess newQualid = starImport.getQualid()
                                .withName(starImport.getQualid().getName().withSimpleName(simpleName));
                        String fqn = changedPackage + "." + simpleName;
                        newQualid = newQualid.withType(findType(fqn, sf));
                        J.Import explicit = starImport.withQualid(newQualid).withId(randomId());
                        expanded.add(i++ == 0 ? explicit : explicit.withPrefix(Space.format("\n")));
                    }
                    return expanded;
                }
                return anImport;
            }));
        }

        /**
         * Checks whether types in the changed package share simple names with types in
         * any of the other star-imported packages, using the JavaSourceSet classpath.
         * Checks both the new package name and the original package name, since the
         * classpath may still have types under the old package name.
         */
        private boolean hasAmbiguity(JavaSourceFile sf, String changedPackage, String originalPackage, Set<String> otherStarPackages, ExecutionContext ctx) {
            if (JavaSourceSet.isDirty(ctx, sf)) {
                // An earlier dependency mutation in this run means the classpath cannot be trusted to
                // prove non-ambiguity; fall back to the safe path and expand the star.
                return true;
            }
            Optional<JavaSourceSet> sourceSet = sf.getMarkers().findFirst(JavaSourceSet.class);
            if (!sourceSet.isPresent()) {
                return false;
            }

            Set<String> typesInChangedPackage = new HashSet<>();
            Set<String> typesInOtherPackages = new HashSet<>();
            for (JavaType.FullyQualified fq : sourceSet.get().getClasspath()) {
                String pkg = fq.getPackageName();
                String className = fq.getClassName();
                if (pkg.equals(changedPackage) || pkg.equals(originalPackage)) {
                    typesInChangedPackage.add(className);
                } else if (otherStarPackages.contains(pkg)) {
                    typesInOtherPackages.add(className);
                }
            }

            for (String typeName : typesInChangedPackage) {
                if (typesInOtherPackages.contains(typeName)) {
                    return true;
                }
            }
            return false;
        }

        private JavaType.FullyQualified findType(String fqn, JavaSourceFile cu) {
            for (JavaType type : cu.getTypesInUse().getTypesInUse()) {
                if (type instanceof JavaType.FullyQualified) {
                    JavaType.FullyQualified fq = (JavaType.FullyQualified) type;
                    if (TypeUtils.fullyQualifiedNamesAreEqual(fq.getFullyQualifiedName(), fqn)) {
                        return fq;
                    }
                }
            }
            Optional<JavaSourceSet> sourceSet = cu.getMarkers().findFirst(JavaSourceSet.class);
            if (sourceSet.isPresent()) {
                for (JavaType.FullyQualified fq : sourceSet.get().getClasspath()) {
                    if (TypeUtils.fullyQualifiedNamesAreEqual(fq.getFullyQualifiedName(), fqn)) {
                        return fq;
                    }
                }
            }
            return JavaType.ShallowClass.build(fqn);
        }

        private @Nullable JavaType updateType(@Nullable JavaType oldType) {
            if (oldType == null || oldType instanceof JavaType.Unknown) {
                return oldType;
            }

            JavaType type = oldNameToChangedType.get(oldType);
            if (type != null) {
                return type;
            }

            if (oldType instanceof JavaType.Parameterized) {
                JavaType.Parameterized pt = (JavaType.Parameterized) oldType;
                pt = pt.withTypeParameters(ListUtils.map(pt.getTypeParameters(), tp -> {
                    if (tp instanceof JavaType.FullyQualified) {
                        JavaType.FullyQualified tpFq = (JavaType.FullyQualified) tp;
                        if (isTargetFullyQualifiedType(tpFq)) {
                            return updateType(tpFq);
                        }
                    }
                    return tp;
                }));

                if (isTargetFullyQualifiedType(pt)) {
                    //noinspection DataFlowIssue
                    pt = pt.withType((JavaType.FullyQualified) updateType(pt.getType()));
                }

                oldNameToChangedType.put(oldType, pt);
                return pt;
            } else if (oldType instanceof JavaType.FullyQualified) {
                JavaType.FullyQualified original = TypeUtils.asFullyQualified(oldType);
                if (isTargetFullyQualifiedType(original)) {
                    JavaType.FullyQualified fq = TypeUtils.asFullyQualified(JavaType.buildType(getNewPackageName(original.getPackageName()) + "." + original.getRawClassName()));
                    //noinspection DataFlowIssue
                    oldNameToChangedType.put(oldType, fq);
                    oldNameToChangedType.put(fq, fq);
                    return fq;
                } else if (oldType instanceof JavaType.Class) {
                    JavaType.Class clazz = ((JavaType.Class) oldType)
                            .withInterfaces(ListUtils.map(original.getInterfaces(), t -> (JavaType.FullyQualified) updateType(t)))
                            .withSupertype((JavaType.FullyQualified) updateType(original.getSupertype()));
                    oldNameToChangedType.put(oldType, clazz);
                    oldNameToChangedType.put(clazz, clazz);
                    return clazz;
                }
            } else if (oldType instanceof JavaType.GenericTypeVariable) {
                JavaType.GenericTypeVariable gtv = (JavaType.GenericTypeVariable) oldType;
                gtv = gtv.withBounds(ListUtils.map(gtv.getBounds(), b -> {
                    if (b instanceof JavaType.FullyQualified && isTargetFullyQualifiedType((JavaType.FullyQualified) b)) {
                        return updateType(b);
                    }
                    return b;
                }));

                oldNameToChangedType.put(oldType, gtv);
                oldNameToChangedType.put(gtv, gtv);
                return gtv;
            } else if (oldType instanceof JavaType.Variable) {
                JavaType.Variable variable = (JavaType.Variable) oldType;
                variable = variable.withOwner(updateType(variable.getOwner()));
                //noinspection DataFlowIssue
                variable = variable.withType(updateType(variable.getType()));
                oldNameToChangedType.put(oldType, variable);
                oldNameToChangedType.put(variable, variable);
                return variable;
            } else if (oldType instanceof JavaType.Array) {
                JavaType.Array array = (JavaType.Array) oldType;
                //noinspection DataFlowIssue
                array = array.withElemType(updateType(array.getElemType()));
                oldNameToChangedType.put(oldType, array);
                oldNameToChangedType.put(array, array);
                return array;
            }
            return oldType;
        }

        private JavaType.@Nullable Method updateType(JavaType.@Nullable Method oldMethodType) {
            if (oldMethodType != null) {
                JavaType.Method method = (JavaType.Method) oldNameToChangedType.get(oldMethodType);
                if (method != null) {
                    return method;
                }

                method = oldMethodType;
                //noinspection DataFlowIssue
                method = method.withDeclaringType((JavaType.FullyQualified) updateType(method.getDeclaringType()))
                        .withReturnType(updateType(method.getReturnType()))
                        .withParameterTypes(ListUtils.map(method.getParameterTypes(), this::updateType));
                oldNameToChangedType.put(oldMethodType, method);
                oldNameToChangedType.put(method, method);
                return method;
            }
            return null;
        }

        private String getNewPackageName(String packageName) {
            return isRecursive() && !newPackageName.endsWith(packageName.substring(oldPackageName.length())) ?
                    newPackageName + packageName.substring(oldPackageName.length()) : newPackageName;
        }

        private boolean isTargetFullyQualifiedType(JavaType.@Nullable FullyQualified fq) {
            return fq != null &&
                   (fq.getPackageName().equals(oldPackageName) && !fq.getClassName().isEmpty() ||
                    isTargetRecursivePackageName(fq.getPackageName()));
        }

        private boolean isTargetRecursivePackageName(String packageName) {
            return isRecursive() &&
                   packageName.startsWith(oldPackageName + ".") &&
                   !packageName.startsWith(newPackageName);
        }

    }

    @Value
    @EqualsAndHashCode(callSuper = false)
    private static class ReferenceChangePackageVisitor extends TreeVisitor<Tree, ExecutionContext> {
        Map<Tree, List<Reference>> matches;
        Reference.Renamer renamer;

        @Override
        public Tree postVisit(Tree tree, ExecutionContext ctx) {
            List<Reference> refs = matches.get(tree);
            if (refs != null) {
                for (Reference ref : refs) {
                    if (ref.supportsRename()) {
                        tree = ref.rename(renamer, new Cursor(getCursor().getParent(), tree), ctx);
                    }
                }
            }
            return tree;
        }
    }

}
