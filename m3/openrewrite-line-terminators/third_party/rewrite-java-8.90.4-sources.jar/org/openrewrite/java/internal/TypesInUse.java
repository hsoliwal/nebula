/*
 * Copyright 2021 the original author or authors.
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * <p>
 * https://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.openrewrite.java.internal;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.jspecify.annotations.Nullable;
import org.openrewrite.Cursor;
import org.openrewrite.java.JavaIsoVisitor;
import org.openrewrite.java.MethodMatcher;
import org.openrewrite.java.TypeNameMatcher;
import org.openrewrite.java.tree.J;
import org.openrewrite.java.tree.JavaSourceFile;
import org.openrewrite.java.tree.JavaType;
import org.openrewrite.java.tree.Javadoc;
import org.openrewrite.java.tree.TypeUtils;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import static java.util.Collections.emptySet;
import static java.util.Collections.newSetFromMap;

@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
@Getter
public class TypesInUse {
    private final JavaSourceFile cu;
    private final Set<JavaType> typesInUse;
    private final Set<JavaType.Method> declaredMethods;
    private final Set<JavaType.Method> usedMethods;
    private final Set<JavaType.Variable> variables;

    /**
     * Packages of the fully qualified types referenced only from documentation comments — Javadoc
     * {@code {@link com.foo.Bar}}, C# {@code <see cref="..."/>}, etc. — each contributing its package
     * (e.g. {@code com.foo}). The types themselves are deliberately excluded from {@link #typesInUse}
     * because a fully qualified doc reference needs no import, so it must not count toward import
     * retention (see #5738). Their packages are recorded here so that package-renaming recipes can still
     * discover them without re-walking the tree. Only the package is retained because that is all such
     * recipes query.
     * <p>
     * This bucket is <em>transient</em>: it is populated only by {@link #build(JavaSourceFile)} and is left
     * empty by {@link #of}, since a serialized type index carries no doc references. It is queried only via
     * {@link #hasDocReferenceInPackage}; the raw set is intentionally not exposed.
     */
    @Getter(AccessLevel.NONE)
    private final Set<String> docReferencePackages;

    /**
     * Lazily-built prefix tree over every fully qualified name reachable via
     * {@link TypeUtils#isAssignableTo(String, JavaType)} starting from any type referenced in this
     * compilation unit. Each terminating node carries two pairs of bits per visibility:
     * <ul>
     *   <li>{@code leaf*} — a real FQN ends here in raw form ({@code $} preserved as part of an
     *       inner-class segment). {@link #hasTypeInPackage} and {@link #hasTypeInPackageOrSubpackage}
     *       check these.</li>
     *   <li>{@code alias*} — the canonical form of an inner-class FQN ({@code $} replaced with
     *       {@code .}) ends here. Lets {@link #hasType} match either form against
     *       {@link TypeUtils#fullyQualifiedNamesAreEqual} semantics without confusing package-shape
     *       queries.</li>
     * </ul>
     * Visibility splits each pair into explicit (reachable from types-in-use or imports — visible
     * without {@code includeImplicit}) and implicit (reachable only through used-method types).
     */
    @Nullable
    private volatile FqnTrie trie;
    private volatile boolean implicitPopulated;

    /**
     * Per-{@link TypeNameMatcher} memo for {@link #hasTypeMatching}. Lazily allocated; keyed by
     * the matcher's pattern combined with the {@code includeImplicit} dimension.
     */
    @Nullable
    private volatile Map<String, Boolean> typeMatchingCache;

    /**
     * {@link #usedMethods} / {@link #declaredMethods} sorted by canonical declaring-type FQN, so a
     * {@link MethodMatcher} carrying a literal declaring-type prefix can binary-search to its window instead of
     * scanning the whole set. Lazily built on first matchable query and cached, mirroring {@link #trie}.
     */
    @Nullable
    private volatile MethodEntry[] usedMethodIndex;
    @Nullable
    private volatile MethodEntry[] declaredMethodIndex;

    public static TypesInUse build(JavaSourceFile cu) {
        FindTypesInUse findTypesInUse = new FindTypesInUse();
        findTypesInUse.visit(cu, 0);
        return new TypesInUse(cu,
                findTypesInUse.getTypes(),
                findTypesInUse.getDeclaredMethods(),
                findTypesInUse.getUsedMethods(),
                findTypesInUse.getVariables(),
                findTypesInUse.getDocReferencePackages());
    }

    /**
     * Constructs a {@link TypesInUse} directly from pre-built sets, skipping the full LST walk
     * performed by {@link #build(JavaSourceFile)}. Intended for callers that can source the same
     * information from outside the tree (e.g. a serialized index).
     */
    public static TypesInUse of(JavaSourceFile cu,
                                Set<JavaType> typesInUse,
                                Set<JavaType.Method> declaredMethods,
                                Set<JavaType.Method> usedMethods,
                                Set<JavaType.Variable> variables) {
        return new TypesInUse(cu, typesInUse, declaredMethods, usedMethods, variables, emptySet());
    }

    /**
     * Whether any fully qualified documentation-comment reference in this compilation unit has a package
     * equal to {@code packageName}, or (when {@code recursive}) starts with {@code packageName + '.'}.
     * Mirrors the per-type package check that package-renaming recipes apply to {@link #typesInUse}, for
     * the references that {@link #typesInUse} deliberately omits.
     */
    public boolean hasDocReferenceInPackage(String packageName, boolean recursive) {
        String recursivePrefix = packageName + ".";
        for (String pkg : docReferencePackages) {
            if (pkg.equals(packageName) || recursive && pkg.startsWith(recursivePrefix)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Whether any type referenced in this compilation unit is assignable to {@code fullyQualifiedType}.
     * Mirrors the loop in {@code UsesType.visit}: types-in-use, imports, and (when {@code includeImplicit})
     * the declaring/return/parameter types of used methods.
     * <p>
     * The first call materializes the closure for the file and caches it; subsequent calls are O(1).
     * {@code $} and {@code .} are treated as equivalent in inner-class FQNs, matching
     * {@link TypeUtils#fullyQualifiedNamesAreEqual(String, String)}.
     */
    public boolean hasType(String fullyQualifiedType, boolean includeImplicit) {
        String canonical = fullyQualifiedType.indexOf('$') < 0 ? fullyQualifiedType : fullyQualifiedType.replace('$', '.');
        return getOrBuildTrie(includeImplicit).hasFqn(canonical, includeImplicit);
    }

    /**
     * Whether this compilation unit references any type whose package equals {@code packageName}
     * exactly (i.e., the {@code com.foo.*} pattern). Navigation to the package node is O(depth);
     * matching is a constant-time check for any real-leaf child (alias children are deliberately
     * ignored, so {@code com.foo.Outer.Inner} from a canonicalized inner-class FQN does not
     * register {@code com.foo.Outer} as a package).
     */
    public boolean hasTypeInPackage(String packageName, boolean includeImplicit) {
        return getOrBuildTrie(includeImplicit).hasLeafAtDepth(packageName, includeImplicit);
    }

    /**
     * Whether this compilation unit references any type whose package equals {@code packageName}
     * or starts with {@code packageName + '.'} (i.e., the {@code com.foo..*} pattern). The
     * descendant-leaf rollup tracks only real leaves, so the answer is O(depth) regardless of
     * trie size.
     */
    public boolean hasTypeInPackageOrSubpackage(String packageName, boolean includeImplicit) {
        return getOrBuildTrie(includeImplicit).hasAnyLeafBelow(packageName, includeImplicit);
    }

    /**
     * Whether any FQN reachable through the assignability closure of this compilation unit
     * matches {@code matcher}. Walks every raw-leaf path in the trie and tests the matcher
     * against the reconstructed FQN — equivalent to the per-element loop in {@code UsesType}'s
     * pre-cache implementation, but iterated once per (file, matcher) pair regardless of how
     * many recipe instances ask. Alias paths are excluded so canonical inner-class FQNs only
     * match through their raw form, mirroring the semantics of {@link #hasTypeInPackage}.
     */
    public boolean hasTypeMatching(TypeNameMatcher matcher, boolean includeImplicit) {
        Map<String, Boolean> cache = typeMatchingCache;
        if (cache == null) {
            cache = new ConcurrentHashMap<>();
            typeMatchingCache = cache;
        }
        String key = (includeImplicit ? "+" : "-") + matcher;
        return cache.computeIfAbsent(key, k -> getOrBuildTrie(includeImplicit).anyLeafFqn(matcher, includeImplicit));
    }

    /**
     * Whether this compilation unit invokes any method matching {@code matcher}.
     */
    public boolean hasMethodUse(MethodMatcher matcher) {
        return anyMethodMatches(matcher, true);
    }

    /** Whether this compilation unit declares any method matching {@code matcher}. */
    public boolean declaresMethod(MethodMatcher matcher) {
        return anyMethodMatches(matcher, false);
    }

    /**
     * When the matcher pins a literal declaring-type prefix and does not need override resolution, binary-search the
     * sorted index to the prefix window and confirm candidates with {@link MethodMatcher#matches(JavaType.Method)};
     * otherwise (leading-wildcard type, or {@code matchOverrides} where the match may live under a subtype key) fall
     * back to a full scan.
     */
    private boolean anyMethodMatches(MethodMatcher matcher, boolean used) {
        Set<JavaType.Method> methods = used ? usedMethods : declaredMethods;
        String prefix = matcher.getDeclaringTypeMatchPrefix();
        if (prefix == null || matcher.isMatchOverrides()) {
            for (JavaType.Method m : methods) {
                if (matcher.matches(m)) {
                    return true;
                }
            }
            return false;
        }

        MethodEntry[] index = used ? usedMethodIndex : declaredMethodIndex;
        if (index == null) {
            index = MethodEntry.index(methods);
            if (used) {
                usedMethodIndex = index;
            } else {
                declaredMethodIndex = index;
            }
        }
        for (int i = MethodEntry.lowerBound(index, prefix); i < index.length && index[i].key.startsWith(prefix); i++) {
            if (matcher.matches(index[i].method)) {
                return true;
            }
        }
        return false;
    }

    private FqnTrie getOrBuildTrie(boolean includeImplicit) {
        FqnTrie t = trie;
        if (t == null) {
            t = buildExplicitTrie();
            trie = t;
        }
        if (includeImplicit && !implicitPopulated) {
            populateImplicitPass(t);
        }
        return t;
    }

    @SuppressWarnings("deprecation")
    private FqnTrie getOrBuildTrie() {
        return getOrBuildTrie(false);
    }

    private FqnTrie buildExplicitTrie() {
        FqnTrie t = new FqnTrie();
        Set<String> visited = new HashSet<>();
        for (JavaType type : typesInUse) {
            JavaType checkType = type instanceof JavaType.Primitive ? type : TypeUtils.asFullyQualified(type);
            walkAssignableTo(checkType, t, true, visited);
        }
        for (J.Import anImport : cu.getImports()) {
            JavaType target = anImport.isStatic()
                    ? anImport.getQualid().getTarget().getType()
                    : anImport.getQualid().getType();
            walkAssignableTo(TypeUtils.asFullyQualified(target), t, true, visited);
        }
        return t;
    }

    private synchronized void populateImplicitPass(FqnTrie t) {
        if (implicitPopulated) return;
        Set<String> visited = new HashSet<>();
        for (JavaType.Method method : usedMethods) {
            walkAssignableTo(method.getDeclaringType(), t, false, visited);
            walkAssignableTo(method.getReturnType(), t, false, visited);
            for (JavaType pt : method.getParameterTypes()) {
                walkAssignableTo(pt, t, false, visited);
            }
        }
        implicitPopulated = true;
    }

    /**
     * Walks the assignability chain of {@code from} and inserts each reached FQN into the trie.
     * Each FQN is inserted in raw form (with {@code $} preserved as part of an inner-class
     * segment) so package-shape queries see the correct package/class boundary; in addition,
     * inner-class FQNs are also inserted as canonical-form aliases so exact lookups by either
     * {@code .} or {@code $} form land on the same node. Mirrors the cases in
     * {@link TypeUtils#isAssignableTo(String, JavaType)}.
     */
    private static void walkAssignableTo(@Nullable JavaType from, FqnTrie trie, boolean explicit, Set<String> visited) {
        if (from == null) {
            return;
        }
        try {
            if (from instanceof JavaType.FullyQualified) {
                JavaType.FullyQualified fq = (JavaType.FullyQualified) from;
                if (from instanceof JavaType.Parameterized) {
                    String parameterized = from.toString();
                    //noinspection ConstantConditions
                    if (parameterized != null && visited.add(parameterized)) {
                        trie.insert(parameterized, explicit);
                    }
                }
                String fqn = fq.getFullyQualifiedName();
                if (visited.add(fqn)) {
                    trie.insert(fqn, explicit);
                    walkAssignableTo(fq.getSupertype(), trie, explicit, visited);
                    for (JavaType.FullyQualified i : fq.getInterfaces()) {
                        walkAssignableTo(i, trie, explicit, visited);
                    }
                }
            } else if (from instanceof JavaType.GenericTypeVariable) {
                for (JavaType bound : ((JavaType.GenericTypeVariable) from).getBounds()) {
                    walkAssignableTo(bound, trie, explicit, visited);
                }
                if (visited.add("java.lang.Object")) {
                    trie.insert("java.lang.Object", explicit);
                }
            } else if (from instanceof JavaType.Primitive) {
                JavaType.Primitive p = (JavaType.Primitive) from;
                String keyword = p.getKeyword();
                if (keyword != null && visited.add(keyword)) {
                    trie.insert(keyword, explicit);
                }
                if (p == JavaType.Primitive.String && visited.add("java.lang.String")) {
                    trie.insert("java.lang.String", explicit);
                }
                if (visited.add("java.lang.Object")) {
                    trie.insert("java.lang.Object", explicit);
                }
            } else if (from instanceof JavaType.Variable) {
                walkAssignableTo(((JavaType.Variable) from).getType(), trie, explicit, visited);
            } else if (from instanceof JavaType.Method) {
                walkAssignableTo(((JavaType.Method) from).getReturnType(), trie, explicit, visited);
            } else if (from instanceof JavaType.Intersection) {
                for (JavaType bound : ((JavaType.Intersection) from).getBounds()) {
                    walkAssignableTo(bound, trie, explicit, visited);
                }
                if (visited.add("java.lang.Object")) {
                    trie.insert("java.lang.Object", explicit);
                }
            } else if (visited.add("java.lang.Object")) {
                trie.insert("java.lang.Object", explicit);
            }
        } catch (Exception ignored) {
        }
    }

    /**
     * Prefix tree over fully qualified names, tokenized on {@code .} only. Each FQN is inserted
     * twice when it contains {@code $}: once raw (so {@code com.foo.Outer$Inner} is the three
     * segments {@code [com, foo, Outer$Inner]}, with the inner-class boundary preserved for
     * package-shape queries) and once as a canonical alias ({@code [com, foo, Outer, Inner]}, so
     * exact-FQN lookups by either form land on the same terminating node).
     * <p>
     * Each node tracks four visibility bits — leaf vs alias, each with explicit vs implicit —
     * plus a descendant-explicit/-implicit rollup that propagates only on the raw insertion path,
     * so {@code com.foo..*} queries don't get false positives from canonical alias paths.
     */
    private static final class FqnTrie {
        // Bit flags packed into a single byte on each Node, replacing six boolean fields.
        // Java 25's compact object headers (-XX:+UseCompactObjectHeaders) shrinks Node from 32 B
        // to 24 B with this packing — material savings on tries with thousands of nodes.
        private static final byte LEAF_EXPLICIT = 1;
        private static final byte LEAF_IMPLICIT = 1 << 1;
        private static final byte ALIAS_EXPLICIT = 1 << 2;
        private static final byte ALIAS_IMPLICIT = 1 << 3;
        private static final byte DESCENDANT_EXPLICIT = 1 << 4;
        private static final byte DESCENDANT_IMPLICIT = 1 << 5;

        private final Node root = new Node();

        /**
         * Insert {@code fqn} as a real leaf at its raw path. If it contains {@code $}, additionally
         * insert the canonicalized path as an alias leaf so {@link #hasFqn} answers either form.
         */
        void insert(String fqn, boolean explicit) {
            if (fqn.isEmpty()) {
                return;
            }
            insertPath(fqn, explicit, false);
            if (fqn.indexOf('$') >= 0) {
                insertPath(fqn.replace('$', '.'), explicit, true);
            }
        }

        private void insertPath(String path, boolean explicit, boolean alias) {
            Node n = root;
            int start = 0;
            int len = path.length();
            // Use String.indexOf('.', start) so the JVM can apply its SIMD-friendly intrinsic
            // for char scans rather than a manual charAt loop.
            while (true) {
                int dot = start < len ? path.indexOf('.', start) : -1;
                int end = dot < 0 ? len : dot;
                // Descendant rollup propagates only for raw-leaf insertions; alias paths do
                // not contribute to "this package has any class beneath it" queries.
                if (!alias) {
                    n.flags |= explicit ? DESCENDANT_EXPLICIT : DESCENDANT_IMPLICIT;
                }
                n = n.findOrAddChild(path, start, end);
                if (dot < 0) {
                    break;
                }
                start = end + 1;
            }
            if (alias) {
                if (explicit) {
                    n.flags |= ALIAS_EXPLICIT;
                } else if ((n.flags & ALIAS_EXPLICIT) == 0) {
                    n.flags |= ALIAS_IMPLICIT;
                }
            } else {
                if (explicit) {
                    n.flags |= LEAF_EXPLICIT;
                } else if ((n.flags & LEAF_EXPLICIT) == 0) {
                    n.flags |= LEAF_IMPLICIT;
                }
            }
        }

        /** Exact-FQN lookup. The query is expected in canonical form (no {@code $}). */
        boolean hasFqn(String canonicalFqn, boolean includeImplicit) {
            Node n = navigate(canonicalFqn);
            if (n == null) {
                return false;
            }
            if ((n.flags & (LEAF_EXPLICIT | ALIAS_EXPLICIT)) != 0) {
                return true;
            }
            return includeImplicit && (n.flags & (LEAF_IMPLICIT | ALIAS_IMPLICIT)) != 0;
        }

        /** {@code com.foo.*}: any FQN whose package is exactly {@code pkg}. */
        boolean hasLeafAtDepth(String pkg, boolean includeImplicit) {
            Node n = navigate(pkg);
            if (n == null) {
                return false;
            }
            byte mask = includeImplicit ? (byte) (LEAF_EXPLICIT | LEAF_IMPLICIT) : LEAF_EXPLICIT;
            for (int i = 0; i < n.childCount; i++) {
                // Deliberately ignore alias bits: a canonicalized inner-class path like
                // [com, foo, Outer, Inner] must not let `com.foo.Outer.*` match.
                if ((n.childNodes[i].flags & mask) != 0) {
                    return true;
                }
            }
            return false;
        }

        /** {@code com.foo..*}: any FQN whose package starts with {@code pkg + '.'} (or equals {@code pkg}). */
        boolean hasAnyLeafBelow(String pkg, boolean includeImplicit) {
            Node n = navigate(pkg);
            if (n == null) {
                return false;
            }
            // Deliberately exclude leaf/alias bits — `pkg..*` matches strict subpackages of pkg,
            // not pkg itself. Descendant flags only track raw-leaf insertions.
            byte mask = includeImplicit ? (byte) (DESCENDANT_EXPLICIT | DESCENDANT_IMPLICIT) : DESCENDANT_EXPLICIT;
            return (n.flags & mask) != 0;
        }

        /**
         * Walks every raw-leaf FQN reachable in this trie and returns {@code true} on the first
         * one that {@code matcher} accepts. Alias paths are skipped so canonicalized inner-class
         * FQNs only match through their raw form, matching {@link TypeUtils#isAssignableTo}'s
         * semantics for the legacy {@code GenericPattern} iteration.
         */
        boolean anyLeafFqn(TypeNameMatcher matcher, boolean includeImplicit) {
            return anyLeafFqn(root, new StringBuilder(), matcher, includeImplicit);
        }

        private static boolean anyLeafFqn(Node node, StringBuilder fqn, TypeNameMatcher matcher, boolean includeImplicit) {
            byte mask = includeImplicit ? (byte) (LEAF_EXPLICIT | LEAF_IMPLICIT) : LEAF_EXPLICIT;
            if ((node.flags & mask) != 0 && matcher.matches(fqn.toString())) {
                return true;
            }
            for (int i = 0; i < node.childCount; i++) {
                int len = fqn.length();
                if (len > 0) {
                    fqn.append('.');
                }
                fqn.append(node.childSegments[i]);
                if (anyLeafFqn(node.childNodes[i], fqn, matcher, includeImplicit)) {
                    return true;
                }
                fqn.setLength(len);
            }
            return false;
        }

        private @Nullable Node navigate(String pkg) {
            if (pkg.isEmpty()) {
                return root;
            }
            Node n = root;
            int start = 0;
            int len = pkg.length();
            // SIMD-friendly intrinsic over manual charAt scan.
            while (start < len) {
                int dot = pkg.indexOf('.', start);
                int end = dot < 0 ? len : dot;
                n = n.findChild(pkg, start, end);
                if (n == null) {
                    return null;
                }
                start = end + 1;
            }
            return n;
        }

        /**
         * Trie node with parallel arrays for children instead of a {@link java.util.HashMap}, so
         * {@link #findChild} can locate a child via {@link String#regionMatches} without
         * allocating a substring of the query string. Average branching for FQN tries is small
         * (typically 1–10), so the linear scan is faster than a hashed lookup once you account
         * for the avoided allocation.
         */
        private static final class Node {
            private static final String[] EMPTY_SEGMENTS = new String[0];
            private static final Node[] EMPTY_NODES = new Node[0];

            String[] childSegments = EMPTY_SEGMENTS;
            Node[] childNodes = EMPTY_NODES;
            int childCount;

            // Six packed bits, see the LEAF_*/ALIAS_*/DESCENDANT_* constants on FqnTrie.
            byte flags;

            /** Locate a child by the segment {@code path[start, end)}; allocation-free. */
            @Nullable Node findChild(String path, int start, int end) {
                int len = end - start;
                for (int i = 0; i < childCount; i++) {
                    String seg = childSegments[i];
                    if (seg.length() == len && path.regionMatches(start, seg, 0, len)) {
                        return childNodes[i];
                    }
                }
                return null;
            }

            /** Insertion-time helper: find or grow. Allocates the segment string once. */
            Node findOrAddChild(String path, int start, int end) {
                int len = end - start;
                for (int i = 0; i < childCount; i++) {
                    String seg = childSegments[i];
                    if (seg.length() == len && path.regionMatches(start, seg, 0, len)) {
                        return childNodes[i];
                    }
                }
                if (childCount == childSegments.length) {
                    int newCap = childSegments.length == 0 ? 4 : childSegments.length * 2;
                    childSegments = childSegments.length == 0 ? new String[newCap] : Arrays.copyOf(childSegments, newCap);
                    childNodes = childNodes.length == 0 ? new Node[newCap] : Arrays.copyOf(childNodes, newCap);
                }
                Node child = new Node();
                childSegments[childCount] = path.substring(start, end);
                childNodes[childCount] = child;
                childCount++;
                return child;
            }
        }
    }

    /**
     * A method paired with its canonical declaring-type FQN ({@code $} replaced with {@code .}), used as the sort key
     * so that {@link MethodMatcher#getDeclaringTypeMatchPrefix() declaring-type prefixes} — exact FQNs, package
     * prefixes from {@code ..*} patterns, and the shorter prefixes of mid-string wildcards alike — all resolve to a
     * contiguous {@code startsWith} window. Canonicalizing here lets inner-class FQNs match either {@code .} or
     * {@code $} prefix form, consistent with {@link TypeUtils#fullyQualifiedNamesAreEqual}.
     */
    private static final class MethodEntry {
        private final String key;
        private final JavaType.Method method;

        private MethodEntry(String key, JavaType.Method method) {
            this.key = key;
            this.method = method;
        }

        static MethodEntry[] index(Set<JavaType.Method> methods) {
            MethodEntry[] entries = new MethodEntry[methods.size()];
            int i = 0;
            for (JavaType.Method m : methods) {
                String fqn = m.getDeclaringType().getFullyQualifiedName();
                entries[i++] = new MethodEntry(fqn.indexOf('$') < 0 ? fqn : fqn.replace('$', '.'), m);
            }
            Arrays.sort(entries, Comparator.comparing(e -> e.key));
            return entries;
        }

        /** First index whose key is {@code >= prefix} — the start of the {@code startsWith(prefix)} run. */
        static int lowerBound(MethodEntry[] index, String prefix) {
            int lo = 0;
            int hi = index.length;
            while (lo < hi) {
                int mid = (lo + hi) >>> 1;
                if (index[mid].key.compareTo(prefix) < 0) {
                    lo = mid + 1;
                } else {
                    hi = mid;
                }
            }
            return lo;
        }
    }

    @Getter
    public static class FindTypesInUse extends JavaIsoVisitor<Integer> {
        private final Set<JavaType> types = newSetFromMap(new IdentityHashMap<>());
        private final Set<JavaType.Method> declaredMethods = newSetFromMap(new IdentityHashMap<>());
        private final Set<JavaType.Method> usedMethods = newSetFromMap(new IdentityHashMap<>());
        private final Set<JavaType.Variable> variables = newSetFromMap(new IdentityHashMap<>());
        private final Set<String> docReferencePackages = new HashSet<>();

        @Override
        public J.Import visitImport(J.Import _import, Integer p) {
            return _import;
        }

        @Override
        public J.Identifier visitIdentifier(J.Identifier identifier, Integer p) {
            Object parent = Objects.requireNonNull(getCursor().getParent()).getValue();
            if (parent instanceof J.ClassDeclaration) {
                // skip type of class
                return identifier;
            } else if (parent instanceof J.MethodDeclaration && ((J.MethodDeclaration) parent).getName() == identifier) {
                // skip method name
                return identifier;
            }
            return super.visitIdentifier(identifier, p);
        }

        @Override
        public J.Lambda.Parameters visitLambdaParameters(J.Lambda.Parameters parameters, Integer integer) {
            for (J j : parameters.getParameters()) {
                if (j instanceof J.VariableDeclarations && ((J.VariableDeclarations) j).getTypeExpression() == null) {
                    // Type is inferred, so no need to visit type to retain import statements
                    return parameters;
                }
                // We only need to check the first parameter, as the rest will be using the same
                break;
            }
            return super.visitLambdaParameters(parameters, integer);
        }

        @Override
        public @Nullable JavaType visitType(@Nullable JavaType javaType, Integer p) {
            if (javaType != null && !(javaType instanceof JavaType.Unknown)) {
                Cursor cursor = getCursor();
                if (javaType instanceof JavaType.Variable) {
                    variables.add((JavaType.Variable) javaType);
                } else if (javaType instanceof JavaType.Method) {
                    if (cursor.getValue() instanceof J.MethodDeclaration) {
                        declaredMethods.add((JavaType.Method) javaType);
                    } else {
                        usedMethods.add((JavaType.Method) javaType);
                    }
                } else if (!(cursor.getValue() instanceof J.ClassDeclaration) &&
                        !(cursor.getValue() instanceof J.Lambda)) {
                    if (isFullyQualifiedJavaDocReference(cursor)) {
                        if (javaType instanceof JavaType.FullyQualified) {
                            docReferencePackages.add(((JavaType.FullyQualified) javaType).getPackageName());
                        }
                    } else {
                        types.add(javaType);
                    }
                }
            }
            return javaType;
        }

        private boolean isFullyQualifiedJavaDocReference(Cursor cursor) {
            // Fully qualified Javadoc references are _using_ those types as much as they are just references;
            // TypesInUse entries determines what imports are retained, and for fully qualified these can be dropped
            if (cursor.getValue() instanceof J.FieldAccess) {
                Iterator<Object> path = cursor.getPath();
                while (path.hasNext()) {
                    Object o = path.next();
                    if (o instanceof Javadoc.Reference) {
                        return true;
                    }
                    if (o instanceof J.Block) {
                        return false;
                    }
                }
            }
            return false;
        }
    }
}
